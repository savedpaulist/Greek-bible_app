# План улучшения myBible

## Статистика кодовой базы

| Слой | Файлов | Строк | Примечание |
|------|--------|-------|------------|
| `core/` | 7 | ~1900 | DB, prefs, models, themes, utils |
| `features/` | 17 | ~6200 | home, search, dictionary, notes, settings, hotkeys |
| `ui/` | 1 | 125 | MainShell |
| root `lib/` | 2 | ~1120 | main.dart, word_popup.dart |
| **Итого** | **27** | **~9345** | |

---

## I. ДУБЛИКАТЫ И ПОВТОРЯЮЩИЙСЯ КОД

### 1. Дублирование `truncateHtml` / `truncateHtmlForPreview`
- `html_parser.dart` — `truncateHtml()`
- `bible_utils.dart` — `truncateHtmlForPreview()`

Обе функции обрезают HTML по границе тега. `truncateHtmlForPreview` дополнительно вырезает секцию «Ссылки».

**Решение**: удалить `truncateHtml` из `html_parser.dart`, использовать единую `truncateHtmlForPreview` из `bible_utils.dart`.
- **Сложность**: 🟢 Лёгкая
- **Нагрузка на производительность**: 🟢 Нулевая

### 2. Дублирование паттернов `_pageDown` / `_pageUp`
- `home_screen.dart` — `_pageDown()`, `_pageUp()`
- `dictionary_article_screen.dart` — `_pageDown()`, `_pageUp()`

Оба реализуют одинаковую логику скролла с учётом `animationsEnabled`.

**Решение**: вынести `ScrollHelper` mixin или extension с общей логикой.
- **Сложность**: 🟢 Лёгкая
- **Нагрузка**: 🟢 Нулевая

### 3. Дублирование `_handleKey` для клавиатурных хоткеев
- `home_screen.dart`
- `dictionary_article_screen.dart`

Идентичная логика обработки `KeyDownEvent`.

**Решение**: общий mixin `KeyboardScrollMixin`.
- **Сложность**: 🟢 Лёгкая

### 4. Дублирование lookupAcrossDictionaries
- `word_popup.dart` — `_lookupInDictionaries()`
- `dictionary_article_screen.dart` — `_openDictionaryLookup()`

Та же логика: получить hits → если пусто — snackbar → если 1 — прямой переход → иначе bottom sheet.

**Решение**: вынести в `bible_utils.dart` или отдельный `dictionary_lookup_helper.dart`.
- **Сложность**: 🟡 Средняя
- **Нагрузка**: 🟢 Нулевая

### 5. Множество setter'ов в `AppState`
В `app_state.dart` — 10+ идентичных setter-методов по шаблону:
```dart
void setXxxSize(double size) {
  xxxSize = size.clamp(min, max);
  prefs.setXxxSize(xxxSize);
  notifyListeners();
}
```

**Решение**: генерик-хелпер `_setDouble(...)`.
- **Сложность**: 🟢 Лёгкая

### 6. Повтор Grid пикера (Book/Chapter/Verse)
- `home_screen.dart` — `_BookChapterDialog` + `_Grid`
- `home_screen.dart` — `_AddParallelDialog` (почти копия)

**Решение**: единый `BookChapterVersePicker` widget.
- **Сложность**: 🟡 Средняя

---

## II. ПРОИЗВОДИТЕЛЬНОСТЬ — КРИТИЧЕСКИЕ УЗКИЕ МЕСТА

### P1: `getMorphologyText()` — N+1 запросов к DB
До **8 отдельных SQL-запросов** на одно слово (каждый `lookup` — отдельный `rawQuery`).

**Решение**: загрузить всю таблицу `morphology_indications` (~200 строк) в `Map<String, String>` при инициализации.
- **Сложность**: 🟢 Лёгкая
- **Выигрыш**: **~40-60 мс → <1 мс** на каждый popup
- **Нагрузка на память**: ~20 KB

### P2: `_loadFullBook()` — загрузка ВСЕЙ книги сразу
При переходе к книге загружаются ВСЕ слова (напр. Псалмы = ~20000 строк). `SELECT * FROM words WHERE book_number=?` — до 200-400 мс.

**Решение**: ленивая загрузка по главам + кеширование. Загружать ±3 главы от текущей, подгружать остальные в фоне.
- **Сложность**: 🟡 Средняя (уже есть `getChaptersRange`, но не используется)
- **Выигрыш**: **200-400 мс → 30-50 мс** initial load

### P3: `groupIntoVerses()` — ненужная сортировка
Данные из DB уже отсортированы (`ORDER BY chapter, verse`), но `groupIntoVerses` всё равно сортирует `.sort()`.

**Решение**: убрать ненужную сортировку, использовать `LinkedHashMap` напрямую.
- **Сложность**: 🟢 Лёгкая
- **Выигрыш**: **5-15 мс** на больших книгах

### P4: `_loadIndicatorsIfNeeded()` — загружает ВСЕ главы книги
Итерирует `state.verses` (вся книга) и собирает все главы, потом загружает indicators для КАЖДОЙ. Для Псалмов — 150 глав × 4 DB-запроса = 600 запросов.

**Решение**: загружать indicators только для **видимых** глав (3-5 максимум).
- **Сложность**: 🟡 Средняя
- **Выигрыш**: **600 запросов → 12-20 запросов**

### P5: `normalizeGreek()` — посимвольная обработка
`StringBuffer` + `_dMap` lookup на каждый символ. Вызывается тысячи раз при индексации.

**Решение**: `String.codeUnits` оптимизация или `compute()` для batch.
- **Сложность**: 🟡 Средняя
- **Выигрыш**: **~20-30%** ускорение индексации

### P6: `buildHtmlWidget` через `flutter_html` — тяжёлый рендеринг
Каждый вызов `Html()` парсит и рендерит HTML. При пролистывании ~30-50 словарных записей — заметные задержки.

**Решение**: для простых случаев (plain text + bold) использовать `RichText` вместо `flutter_html`.
- **Сложность**: 🔴 Высокая
- **Выигрыш**: **~3-5x** ускорение рендеринга preview

### P7: `VersePreviewSheet._load()` — вызывает `getBooks()` каждый раз
`await widget.db.getBooks()` при каждом открытии preview стиха.

**Решение**: использовать `context.read<AppState>().books` (уже загружены).
- **Сложность**: 🟢 Лёгкая
- **Выигрыш**: **~10-20 мс** на каждый preview

### P8: `_ensureTopicIndex` — тяжёлая миграция в main isolate
ALTER TABLE + batch UPDATE для 8 словарей при первом запуске.

**Решение**: мигрировать в фоновом isolate, показать progress bar.
- **Сложность**: 🟡 Средняя

---

## III. АНАЛИЗ ПО ЭКРАНАМ

---

### Экран 1: HomeScreen (Библия) — 1787 строк

**Текущее состояние**: Функциональный, но монолитный. Самый большой файл проекта.

**Проблемы**:
1. **1787 строк** — смешаны виджеты (`_VerseBlock`, `_WordTile`, `_BlinkWrapper`, `_Grid`, `_BookChapterDialog`, `_CommentsSheet`, `_ParallelVersesSheet`, `_AddParallelDialog`)
2. **Глобальный `OverlayEntry? _activeWordOverlay`** — file-level мутабельная переменная
3. **`_loadIndicatorsIfNeeded`** грузит indicators для всех глав книги
4. **`_buildText` фильтрует markups** на каждый rebuild
5. **FutureBuilder** в `_BookChapterDialog` — повторные SQL-запросы при каждом `setState`

**Ориентир (Logos / BlueBible)**:
- Мгновенный переход между главами (предзагрузка ±2 главы)
- Split-view для параллельных текстов
- Inline Strong's definitions (тултип при наведении)
- Подсветка по частям речи (глагол / существительное / прилаг.)
- Перекрёстные ссылки inline в margins

**План улучшений**:

| # | Задача | Сложность | Приоритет | Производительность |
|---|--------|-----------|-----------|--------------------|
| H1 | Разбить на файлы: `verse_block.dart`, `word_tile.dart`, `book_picker.dart`, `comment_sheets.dart` | 🟡 | P1 | Нейтрально |
| H2 | Ленивая загрузка по главам (P2) | 🟡 | P1 | ⚡⚡⚡ |
| H3 | Кешировать `morphology_indications` в RAM (P1) | 🟢 | P1 | ⚡⚡⚡ |
| H4 | Загружать indicators только для видимых глав (P4) | 🟡 | P1 | ⚡⚡ |
| H5 | Pre-compute `verseMarkups` map вместо `.where().toList()` | 🟢 | P2 | ⚡ |
| H6 | Кешировать FutureBuilder результаты через `AsyncMemoizer` | 🟢 | P2 | ⚡ |
| H7 | Inline Strong's definitions (как Logos) | 🔴 | P3 | Нейтрально |
| H8 | Split-view для двух переводов | 🔴 | P3 | Нейтрально |
| H9 | Подсветка частей речи (цвет по морф. категории) | 🟡 | P3 | Нейтрально |
| H10 | Margin-based cross-references (как Logos) | 🔴 | P4 | Нейтрально |

**Заключение**: Экран требует декомпозиции (1787 строк — чрезмерно) и 3 критических оптимизаций производительности (P1, P2, P4). После этого будет comparable с Logos по скорости отклика.

---

### Экран 2: SearchScreen (Поиск) — 599 строк

**Текущее состояние**: Хороший. 5 режимов поиска, история, подсветка.

**Проблемы**:
1. **300 последовательных SQL-запросов** для загрузки слов каждого результата
2. **Поиск без debounce**
3. **Nested ListView** (`ListView` внутри `ListView`)
4. **`_searchAllDictionaries`** — лишний wrapper-метод

**План улучшений**:

| # | Задача | Сложность | Приоритет | Производительность |
|---|--------|-----------|-----------|--------------------|
| S1 | Batch-загрузка слов: один SQL `WHERE (book, ch, v) IN (...)` | 🟡 | P1 | ⚡⚡⚡ |
| S2 | Debounce для поиска по слову (300 мс) | 🟢 | P2 | ⚡⚡ |
| S3 | Заменить nested ListView на `SliverList` + `CustomScrollView` | 🟡 | P2 | ⚡ |
| S4 | Удалить `_searchAllDictionaries` (дубль) | 🟢 | P3 | 🟢 |
| S5 | FTS5 вместо FTS4 для полнотекстового поиска | 🟡 | P3 | ⚡⚡ |

**Заключение**: Главная проблема — sequential loading слов. Batch-загрузка даст 10-20x ускорение поиска. В целом экран хорошо спроектирован.

---

### Экран 3: Словари (3 файла, ~530 строк)

**Текущее состояние**: Хороший. Пагинация, поиск, фильтр "в содержании".

**Проблемы**:
1. `entries = [...entries, ...next]` создаёт новый список при каждом `loadMore`
2. `flutter_html` для каждой статьи — главный bottleneck
3. Нет кеша статей
4. `DictionaryArticleScreen.db` — тип `dynamic`
5. Нет навигации назад/вперёд внутри словаря

**Ориентир (лучшие практики)**:
- Алфавитный scroll bar (A-Z быстрая навигация)
- Preview на hover / long press
- Табы между словарями для одного слова
- История просмотренных статей (breadcrumb)
- Full-text search с подсветкой

**План улучшений**:

| # | Задача | Сложность | Приоритет | Производительность |
|---|--------|-----------|-----------|--------------------|
| D1 | `List.addAll` вместо spread при loadMore | 🟢 | P1 | ⚡ |
| D2 | LRU-кеш для рендеренных статей (top-50) | 🟡 | P1 | ⚡⚡ |
| D3 | Типизировать `db` (вместо `dynamic`) | 🟢 | P1 | 🟢 |
| D4 | Алфавитный sidebar scroll bar | 🟡 | P2 | Нейтрально |
| D5 | История просмотра статей + breadcrumb | 🟡 | P2 | Нейтрально |
| D6 | Табы для views (BDAG / LSJ / Strongs) одного слова | 🔴 | P3 | Нейтрально |

**Заключение**: Словари работают стабильно. Типизация `db` и spread-fix — быстрые улучшения. LRU-кеш значительно ускорит повторные просмотры.

---

### Экран 4: Заметки — 636 строк (+ editor 905 + templates 396)

**Текущее состояние**: Базовый. Папки, шаблоны, markdown, `[[wikilinks]]`.

**Ориентир (Obsidian / Zettelkasten)**

Заметки — самая отстающая часть приложения для Zettelkasten подхода.

**Что отсутствует**:
1. **Граф связей** — главная фича Zettelkasten. Нет визуализации graph view
2. **Backlinks** — нет отображения «кто ссылается на эту заметку»
3. **Тегирование** — нет `#тегов`
4. **Markdown rendering** — нет preview в real-time (только edit)
5. **Полнотекстовый поиск по заметкам** — только `LIKE '%query%'`
6. **Atomic notes** — нет специального UI для коротких заметок
7. **Daily notes** — нет автозаметки дня
8. **Command palette** — нет быстрого доступа к действиям
9. **Bible reference linking** — нет автодополнения `[[Быт 1:1]]`
10. **Экспорт/импорт** — нет синхронизации

**План улучшений**:

| # | Задача | Сложность | Приоритет | Производительность |
|---|--------|-----------|-----------|--------------------|
| N1 | Backlinks: показывать «Входящие ссылки» в note editor | 🟡 | P1 | ⚡ |
| N2 | #Теги — парсинг `#tag` + фильтрация по тегам | 🟡 | P1 | Нейтрально |
| N3 | Markdown preview (split или toggle) | 🟡 | P1 | Нейтрально |
| N4 | FTS-индекс по заметкам (`CREATE VIRTUAL TABLE notes_fts USING fts5`) | 🟡 | P2 | ⚡⚡ |
| N5 | Автодополнение `[[` → список заметок / refs | 🟡 | P2 | Нейтрально |
| N6 | Graph view (flutter_force_directed_graph) | 🔴 | P3 | Нейтрально |
| N7 | Daily note | 🟢 | P3 | Нейтрально |
| N8 | Bible-aware reference resolver `[[Быт 1:1]]` → navigation | 🟡 | P3 | Нейтрально |
| N9 | Экспорт в markdown файлы / Obsidian vault | 🟡 | P4 | Нейтрально |
| N10 | Pin/favorite заметки | 🟢 | P4 | Нейтрально |

**Заключение**: Ключевые отличия от Zettelkasten — нет backlinks и graph view. Реализация backlinks + тегов превратит заметки из простого блокнота в полноценную систему знаний.

---

### Экран 5: Настройки — 810 строк

**Текущее состояние**: Хороший. HSL Color picker, font preview, все настройки.

**Проблемы**:
1. 810 строк — стоит вынести color picker в отдельный файл
2. `_HueWheelPainter` рисует 360 дуг на каждый repaint (можно кешировать)
3. Нет разделения на секции/подстраницы

**План улучшений**:

| # | Задача | Сложность | Приоритет |
|---|--------|-----------|-----------| 
| ST1 | Вынести color picker в `widgets/color_picker.dart` | 🟢 | P2 |
| ST2 | Кешировать hue ring в `ui.Image` | 🟡 | P3 |
| ST3 | Группировка в expandable sections | 🟢 | P3 |

**Заключение**: ✅ Работает хорошо. Декомпозиция color picker — косметическое улучшение.

---

### Экран 6: Горячие клавиши — 196 строк

**Заключение**: ✅ Готов. Минимальный, чистый. Нет проблем.

---

### Экран 7: MainShell — 125 строк

**Проблема**: `IndexedStack` держит все 3 таба в памяти.

| # | Задача | Сложность | Приоритет |
|---|--------|-----------|-----------| 
| M1 | Lazy construction для неактивных табов | 🟢 | P3 |

**Заключение**: ✅ Работает хорошо. Lazy-load — опционально для слабых устройств.

---

## IV. АРХИТЕКТУРНЫЕ УЛУЧШЕНИЯ

### A1. Isolate для тяжёлых DB операций
`buildIndex()`, `_ensureTopicIndex()`, `normalizeGreek()` в batch — всё в main isolate.

**Решение**: `compute()` / `Isolate.run()` для построения индекса, миграций, batch-нормализации.
- **Сложность**: 🟡 Средняя
- **Выигрыш**: UI не замерзает

### A2. Кешировать `getBooks()`
Вызывается минимум 3 раза — каждый раз SQL.

**Решение**: один раз загрузить в `DBService._books` + getter.
- **Сложность**: 🟢 Лёгкая
- **Выигрыш**: ~45 мс

### A3. Repository pattern для `NotesProvider`
`NotesProvider` — тонкий proxy над `NotesDB`, дублирует каждый метод 1:1 (30+ методов).

**Решение**: `ValueNotifier<List<NoteModel>>` для списка + прямые вызовы `NotesDB` для CRUD.
- **Сложность**: 🟡 Средняя

### A4. `CustomThemeColors` — заменить switch на Map
`getByRole` и `withRole` — свитчи на 17 кейсов.

**Решение**: хранить цвета в `Map<String, Color>`.
- **Сложность**: 🟡 Средняя

### A5. `DBService` — слишком много ответственностей
Один класс = Библия + словари + морфология + FTS-индекс + нормализация.

**Решение**: разделить на `BibleRepository`, `MorphologyRepository`, `SearchIndexService`.
- **Сложность**: 🟡 Средняя

---

## V. КОНКРЕТНЫЕ ОПТИМИЗАЦИИ КОДА

### O1. `allChapters` — пересчёт каждый раз
```dart
List<int> get allChapters =>
    _verses.map((v) => v.chapter).toSet().toList()..sort();
```
Вызывается при каждом обращении → O(n).

**Решение**: кешировать при `_verses =` assignment.

### O2. `_copyVerse` — неоптимальная конкатенация
`buffer.clear(); buffer.write(s.trimRight())` при каждой пунктуации.

**Решение**: сначала собрать слова в `List<String>`, потом `join`.

### O3. Search results — `normalizeGreek()` в `_isMatch()` на каждый build
```dart
bool _isMatch(WordModel w) {
  final normWord = normalizeGreek(w.word); // expensive!
}
```

**Решение**: предварительно нормализовать слова при получении результатов.
- **Выигрыш**: **~50-100 мс** на 300 результатов

### O4. `VersePreviewSheet` — дублирующий `getBooks()` запрос
**Решение**: передавать `bookName` как параметр или читать из `AppState`.

### O5. `DictionaryEntry.fromMap` — assigns `strongs` from `topic`
```dart
strongs: map['topic'] as String?,  // ← семантическая ошибка
```
**Решение**: убрать `strongs` из `DictionaryEntry` (нигде не используется корректно).

---

## VI. ПРИОРИТЕЗИРОВАННЫЙ ROADMAP

### 🚀 Фаза 1 — Quick wins (1-2 дня)
- [ ] Кешировать `morphology_indications` в RAM (P1)
- [ ] Кешировать `getBooks()` (A2)
- [ ] Убрать дубль `truncateHtml` (I.1)
- [ ] `allChapters` кеширование (O1)
- [ ] Убрать `getBooks()` из `VersePreviewSheet` (O4, P7)
- [ ] Предварительная нормализация в search results (O3)
- [ ] `List.addAll` вместо spread в DictionaryProvider (D1)
- [ ] Типизировать `db` в DictionaryArticleScreen (D3)

### ⚡ Фаза 2 — Значительные улучшения (3-5 дней)
- [ ] Ленивая загрузка книги по главам (P2, H2)
- [ ] Indicators только для видимых глав (P4, H4)
- [ ] Batch-загрузка слов для search results (S1)
- [ ] Разбить home_screen.dart на файлы (H1)
- [ ] Общий ScrollHelper/KeyboardMixin (I.2, I.3)
- [ ] Общий dictionary lookup helper (I.4)

### 📝 Фаза 3 — Notes → Zettelkasten (5-7 дней)
- [ ] Backlinks (N1)
- [ ] #Теги (N2)
- [ ] Markdown preview (N3)
- [ ] FTS5 для заметок (N4)
- [ ] `[[` autocomplete (N5)
- [ ] Daily note (N7)

### 📖 Фаза 4 — Logos-level Bible features (7-14 дней)
- [ ] Split-view для параллельных текстов (H8)
- [ ] Подсветка частей речи (H9)
- [ ] Dictionary tabs для одного слова (D6)
- [ ] Graph view для заметок (N6)
- [ ] Isolate для тяжёлых операций (A1)
- [ ] FTS5 вместо FTS4 (S5)

### 🎨 Фаза 5 — Polish & Architecture (3-5 дней)
- [ ] Разделить DBService (A5)
- [ ] Repository pattern для NotesProvider (A3)
- [ ] Map-based CustomThemeColors (A4)
- [ ] Экспорт заметок в Obsidian (N9)
- [ ] Алфавитный sidebar для словарей (D4)

---

## VII. ОЖИДАЕМЫЕ ОРИЕНТИРЫ ПОСЛЕ ОПТИМИЗАЦИИ

| Операция | Сейчас (оценка) | Цель |
|----------|-----------------|------|
| `loadFullBook` (большая книга) | 200-400 мс | 30-50 мс |
| `getWordDetail` | 40-80 мс | 5-10 мс |
| `getMorphologyText` | 15-30 мс | <1 мс |
| `searchByWord` (FTS) | 50-100 мс | 30-50 мс |
| `groupIntoVerses` (10k words) | 15-30 мс | 5-10 мс |
| `_loadIndicatorsIfNeeded` | 200-500 мс | 20-50 мс |
| `buildHtmlWidget` (large article) | 100-300 мс | 50-100 мс |

---

## ИТОГО

**Общая оценка**: кодовая база **хорошо структурирована** для текущего размера. Главные проблемы — производительностные (N+1 SQL queries, загрузка всей книги, indicators для всех глав). Notes-модуль требует значительного расширения для Zettelkasten подхода.

**ТОП-3 действия с максимальным ROI**:
1. **Кешировать `morphology_indications`** — мгновенный эффект, 1 час работы
2. **Ленивая загрузка по главам** — заметный UX, 4-6 часов
3. **Backlinks + теги для Заметок** — ключевая фича Zettelkasten, 2-3 дня
