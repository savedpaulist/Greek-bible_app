// lib/ui/main_shell.dart
//
// Three-tab layout: Notes | Bible | Dictionaries
// Navigation via PageView (slide animation).
// Each tab owns a nested Navigator so sub-screens push *inside* the tab
// and the bottom bar stays visible.

import 'dart:ui';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:provider/provider.dart';
import '../core/app_state.dart';
import '../features/notes/view/notes_screen.dart';
import '../features/home/view/home_screen.dart';
import '../features/dictionary/view/dictionary_screen.dart';

// ─────────────────────────────────────────────────────────────────────────────

class MainShell extends StatefulWidget {
  const MainShell({super.key, this.initialPage = 1});

  final int initialPage;

  @override
  State<MainShell> createState() => MainShellState();
}

class MainShellState extends State<MainShell> {
  // Удалено: ValueNotifier _showBottomBar, теперь используется AppState.showBottomNavBar

  // ── Mouse-drag gesture tracking (macOS / Windows with mouse) ───────────
  // Accumulate horizontal delta so a single mouse-wheel flick = one page change
  double _mouseHorizAccum = 0;
  static const _mousePageThreshold = 80.0;

  void setBottomBarVisible(bool visible) {
    // Удалено: управление _showBottomBar, теперь используется AppState.showBottomNavBar
  }

  late int _currentPage;
  late final PageController _pageController;

  // One navigator key per tab — preserves sub-screen state
  final _navKeys = List.generate(3, (_) => GlobalKey<NavigatorState>());

  @override
  void initState() {
    super.initState();
    _currentPage = widget.initialPage;
    _pageController = PageController(initialPage: _currentPage);
  }

  @override
  void dispose() {
    // Удалено: _showBottomBar.dispose()
    _pageController.dispose();
    super.dispose();
  }

  // ── Public API ─────────────────────────────────────────────────────────────

  /// Animate to [page] from outside (e.g. deep-link, notification).
  void goToPage(int page) {
    _pageController.animateToPage(
      page,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  // ── Internal ───────────────────────────────────────────────────────────────

  void _onPageChanged(int page) => setState(() => _currentPage = page);

  /// Handle Android back-button: pop nested navigator first, then allow exit.
  Future<bool> _onWillPop() async {
    final nav = _navKeys[_currentPage].currentState;
    if (nav != null && nav.canPop()) {
      nav.pop();
      return false;
    }
    return true;
  }


  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
      final appState = context.watch<AppState>();
    // Only subscribe to the error field — avoids full-shell rebuild on every
    // AppState change (e.g. scroll updates, font size tweaks, etc.)
    final error = context.select<AppState, String?>((s) => s.error);
    Widget errorWidget = error != null && error.isNotEmpty
        ? Center(child: Text('Ошибка: $error', style: const TextStyle(color: Colors.red, fontSize: 18)))
        : const SizedBox.shrink();

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final shouldPop = await _onWillPop();
        if (shouldPop && context.mounted) Navigator.of(context).maybePop();
      },
      child: Scaffold(
        extendBody: true,
        body: Stack(
          children: [
            if (error != null && error.isNotEmpty)
              errorWidget
            else
              Listener(
                onPointerSignal: (event) {
                  if (event is PointerScrollEvent) {
                    final dx = event.scrollDelta.dx;
                    final dy = event.scrollDelta.dy;
                    if (dx.abs() > dy.abs() && dx.abs() > 5) {
                      _mouseHorizAccum += dx;
                      if (_mouseHorizAccum > _mousePageThreshold) {
                        _mouseHorizAccum = 0;
                        if (_currentPage < 2) goToPage(_currentPage + 1);
                      } else if (_mouseHorizAccum < -_mousePageThreshold) {
                        _mouseHorizAccum = 0;
                        if (_currentPage > 0) goToPage(_currentPage - 1);
                      }
                    } else {
                      _mouseHorizAccum = 0;
                    }
                  }
                },
                child: PageView(
                  controller: _pageController,
                  onPageChanged: _onPageChanged,
                  physics: _currentPage == 0
                      ? const _NoLeftSwipePhysics()
                      : const BouncingScrollPhysics(),
                  children: [
                    _TabNavigator(
                        navigatorKey: _navKeys[0], child: const NotesScreen()),
                    _TabNavigator(
                      navigatorKey: _navKeys[1],
                      child: HomeScreen(
                        onScrollDirection: (isScrollingDown) {
                          setBottomBarVisible(!isScrollingDown);
                        },
                      ),
                    ),
                    _TabNavigator(
                      navigatorKey: _navKeys[2],
                      child: const DictionaryScreen(embedded: true),
                    ),
                  ],
                ),
              ),
            // ...other overlays/widgets if any...
          ],
        ),
        bottomNavigationBar: appState.showBottomNavBar
            ? SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: GNav(
                    selectedIndex: _currentPage,
                    onTabChange: (index) => goToPage(index),
                    mainAxisAlignment: MainAxisAlignment.center,
                    tabBorderRadius: 20,
                    tabActiveBorder: Border.all(
                      color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                      width: 1,
                    ),
                    tabBackgroundColor: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.2),
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    activeColor: Theme.of(context).colorScheme.primary,
                    iconSize: 24,
                    gap: 4,
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                    tabs: const [
                      GButton(icon: Icons.note_alt_outlined, text: 'Заметки'),
                      GButton(icon: Icons.auto_stories_outlined, text: 'Библия'),
                      GButton(icon: Icons.menu_book_outlined, text: 'Словари'),
                    ],
                  ),
                ),
              )
            : null,
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Semi-transparent GNav bottom bar
// ─────────────────────────────────────────────────────────────────────────────

class BottomPanelWidget extends StatelessWidget {
  final bool show;
  final int currentIndex;
  final ValueChanged<int> onTabChange;

  const BottomPanelWidget({
    Key? key,
    required this.show,
    required this.currentIndex,
    required this.onTabChange,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AnimatedSlide(
      duration: const Duration(milliseconds: 250),
      offset: show ? Offset.zero : const Offset(0, 1),
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 250),
        opacity: show ? 1 : 0,
        child: _BottomNavBar(
          currentIndex: currentIndex,
          onTabChange: onTabChange,
        ),
      ),
    );
  }
}

class _BottomNavBar extends StatelessWidget {
  const _BottomNavBar({
    required this.currentIndex,
    required this.onTabChange,
    // required this.fixedWidth,
  });

  final int currentIndex;
  final ValueChanged<int> onTabChange;
  final double fixedWidth = 200;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    // КРИТИЧЕСКИ ВАЖНО: не использовать Align как корневой виджет в
    // bottomNavigationBar. Align при loose-constraints занимает ВЕСЬ экран
    // по высоте → Scaffold думает, что bottom nav = высота экрана → body
    // получает высоту 0 → весь контент невидим.
    // Row с mainAxisAlignment.center: высота = высота дочернего виджета.
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
            child: Container(
              width: fixedWidth,
              decoration: const BoxDecoration(
                color: Color.fromARGB(0, 255, 255, 255), // прозрачный
              ),
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: GNav(
                    selectedIndex: currentIndex,
                    onTabChange: onTabChange,
                    mainAxisAlignment: MainAxisAlignment.center,
                    tabBorderRadius: 20,
                    tabActiveBorder: Border.all(
                      color: cs.primary.withValues(),
                      width: 1,
                    ),
                    tabBackgroundColor: cs.primaryContainer.withValues(),
                    color: cs.onSurfaceVariant,
                    activeColor: cs.primary,
                    iconSize: 24,
                    gap: 4,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 6),
                    tabs: const [
                      GButton(icon: Icons.note_alt_outlined, text: 'Заметки'),
                      GButton(
                          icon: Icons.auto_stories_outlined, text: 'Библия'),
                      GButton(
                          icon: Icons.menu_book_outlined, text: 'Словари'),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Custom scroll physics: blocks right-swipe (back) on the first page.
// The leftmost tab has nothing to its left — prevent accidentally swiping
// into void while the Notes drawer is also a right-edge gesture.
// ─────────────────────────────────────────────────────────────────────────────

class _NoLeftSwipePhysics extends ScrollPhysics {
  const _NoLeftSwipePhysics({super.parent});

  @override
  _NoLeftSwipePhysics applyTo(ScrollPhysics? ancestor) =>
      _NoLeftSwipePhysics(parent: buildParent(ancestor));

  @override
  double applyPhysicsToUserOffset(ScrollMetrics pos, double offset) {
    // offset > 0 means a right-swipe (trying to go left of page 0) — block it
    if (pos.pixels <= pos.minScrollExtent && offset > 0) return 0;
    return offset;
  }

  @override
  bool shouldAcceptUserOffset(ScrollMetrics position) => true;
}

// ─────────────────────────────────────────────────────────────────────────────
// Wraps a root widget in its own nested Navigator.
// StatefulWidget so the Navigator is NOT recreated on every parent rebuild —
// this keeps the route alive and prevents a stale closure from being used.
// ─────────────────────────────────────────────────────────────────────────────

class _TabNavigator extends StatefulWidget {
  const _TabNavigator({required this.navigatorKey, required this.child});

  final GlobalKey<NavigatorState> navigatorKey;
  final Widget child;

  @override
  State<_TabNavigator> createState() => _TabNavigatorState();
}

class _TabNavigatorState extends State<_TabNavigator> {
  late Route<dynamic> _initialRoute;

  @override
  void initState() {
    super.initState();
    // Build the initial route once — no slide/fade animation so the tab
    // appears instantly when the app opens.
    _initialRoute = PageRouteBuilder<void>(
      pageBuilder: (_, __, ___) => widget.child,
      transitionDuration: Duration.zero,
      reverseTransitionDuration: Duration.zero,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Navigator(
      key: widget.navigatorKey,
      onGenerateInitialRoutes: (_, __) => [_initialRoute],
      onGenerateRoute: (settings) => MaterialPageRoute(
        builder: (_) => widget.child,
        settings: settings,
      ),
    );
  }
}
