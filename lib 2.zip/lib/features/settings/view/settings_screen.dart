// lib/features/settings/view/settings_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/app_state.dart';
import '../../hotkey_settings/view/hotkey_settings_screen.dart';
import 'sections/appearance_settings.dart';
import 'sections/bible_settings.dart';
import 'sections/notes_settings.dart';
import 'sections/dictionary_settings.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Настройки')),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8),
        children: [
          ListTile(
            leading: const Icon(Icons.palette_outlined),
            title: const Text('Внешний вид'),
            subtitle: const Text('Тема, цвета, анимации'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const AppearanceSettingsScreen(),
              ),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.menu_book_outlined),
            title: const Text('Шрифт Библии'),
            subtitle: const Text(
              'Размер, межстрочный интервал, критический текст',
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const BibleSettingsScreen(),
              ),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.edit_note),
            title: const Text('Редактор заметок'),
            subtitle: const Text('Шрифт, размер, цвет текста'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const NotesSettingsScreen(),
              ),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.book_outlined),
            title: const Text('Словарь'),
            subtitle: const Text('Размер шрифта'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const DictionarySettingsScreen(),
              ),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.keyboard),
            title: const Text('Горячие клавиши'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const HotkeySettingsScreen(),
              ),
            ),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.history),
            title: const Text('История поиска'),
            subtitle: Text('Макс. ${state.searchHistoryLimit} записей'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showSearchHistorySettings(context, state),
          ),
          if (state.searchHistory.isNotEmpty)
            ListTile(
              title: const Text('Очистить историю'),
              leading: const Icon(Icons.delete_outline),
              onTap: () {
                state.clearSearchHistory();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('История очищена')),
                );
              },
            ),
          const Divider(),
          ListTile(
            leading: Icon(
              state.indexError != null
                  ? Icons.error_outline
                  : state.isIndexing
                      ? Icons.hourglass_top
                      : Icons.build,
              color: state.indexError != null
                  ? cs.error
                  : state.isIndexing
                      ? cs.primary
                      : null,
            ),
            title: Text(
              state.indexError != null
                  ? 'Ошибка индексации'
                  : state.isIndexing
                      ? 'Построение индекса…'
                      : 'Перестроить индекс',
            ),
            subtitle: state.isIndexing
                ? ValueListenableBuilder<double>(
                    valueListenable: state.indexProgress,
                    builder: (context, progress, _) => Text(
                      '${(progress * 100).round()}%',
                      style: TextStyle(fontSize: 12, color: cs.secondary),
                    ),
                  )
                : state.indexError != null
                    ? Text(
                        state.indexError!,
                        style: TextStyle(fontSize: 12, color: cs.error),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      )
                    : const Text('Полнотекстовый поиск по словам'),
            onTap: state.isIndexing ? null : () => state.rebuildIndex(),
          ),
          SwitchListTile(
            title: const Text('Скрывать нижнюю панель'),
            subtitle: const Text('Автоскрытие при чтении'),
            value: state.bottomBarAutoHide,
            onChanged: state.setBottomBarAutoHide,
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  void _showSearchHistorySettings(BuildContext context, AppState state) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Максимум записей в истории',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 12),
            DropdownButton<int>(
              value: state.searchHistoryLimit,
              isExpanded: true,
              items: const [5, 10, 20, 50, 100, 200, 500, 1000]
                  .map((v) => DropdownMenuItem(value: v, child: Text('$v')))
                  .toList(),
              onChanged: (v) {
                if (v != null) state.setSearchHistoryLimit(v);
              },
            ),
          ],
        ),
      ),
    );
  }
}
