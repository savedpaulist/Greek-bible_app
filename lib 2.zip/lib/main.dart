// lib/main.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/app_state.dart';
import 'core/db/db_service.dart';
import 'core/db/dictionary_service.dart';
import 'core/prefs/prefs_service.dart';

// import 'features/home/home_module.dart';
import 'features/dictionary/dictionary_module.dart';
import 'features/settings/view/settings_screen.dart';
import 'ui/main_shell.dart';
import 'features/notes/provider/notes_provider.dart';
import 'features/notes/data/notes_db.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final db    = DBService();
  final prefs = PrefsService();

  await prefs.init();
  await db.init();

  final dictService = DictionaryService(db.dictDbs);

  final basePath = prefs.dbStoragePath; // null если не задано
  final notesDb = NotesDB();
  await notesDb.init(basePath: basePath);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => AppState(db: db, prefs: prefs)..initialize(),
        ),
        ChangeNotifierProvider(
          create: (_) => DictionaryProvider(dictService),
        ),
        ChangeNotifierProvider(
          create: (_) => NotesProvider(notesDb)..load(),
        ),
      ],
      child: const BibleApp(),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// GruvBox-inspired themes
// ─────────────────────────────────────────────────────────────────────────────

// GruvBox dark palette
const _gbDarkBg       = Color(0xFF282828);
const _gbDarkBg0Hard  = Color(0xFF1D2021);
const _gbDarkBg1      = Color(0xFF3C3836);
const _gbDarkBg2      = Color(0xFF504945);
const _gbDarkFg       = Color(0xFFEBDBB2);
const _gbDarkFg1      = Color(0xFFD5C4A1);
const _gbDarkAqua     = Color(0xFF8EC07C);
const _gbDarkBlue     = Color(0xFF83A598);
const _gbDarkOrange   = Color(0xFFFE8019);
const _gbDarkRed      = Color(0xFFFB4934);
const _gbDarkGray     = Color(0xFF928374);

// GruvBox light palette
const _gbLightBg      = Color(0xFFFBF1C7);
const _gbLightBg1     = Color(0xFFEBDBB2);
const _gbLightBg2     = Color(0xFFD5C4A1);
const _gbLightFg      = Color(0xFF3C3836);
const _gbLightFg1     = Color(0xFF504945);
const _gbLightBlue    = Color(0xFF076678);
const _gbLightAqua    = Color(0xFF427B58);
const _gbLightOrange  = Color(0xFFAF3A03);
const _gbLightRed     = Color(0xFF9D0006);
const _gbLightGray    = Color(0xFF928374);

ThemeData buildLightTheme(String font) {
  final cs = ColorScheme.light(
    primary:              _gbLightBlue,
    onPrimary:            Colors.white,
    primaryContainer:     _gbLightBg1,
    onPrimaryContainer:   _gbLightFg,
    secondary:            _gbLightAqua,
    onSecondary:          Colors.white,
    secondaryContainer:   _gbLightBg2,
    onSecondaryContainer: _gbLightFg1,
    tertiary:             _gbLightOrange,
    error:                _gbLightRed,
    surface:              _gbLightBg,
    onSurface:            _gbLightFg,
    surfaceContainerHighest: _gbLightBg2,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    fontFamily: font,
    scaffoldBackgroundColor: _gbLightBg,
    textTheme: TextTheme(
      bodyMedium:  TextStyle(fontFamily: font, color: _gbLightFg),
      bodyLarge:   TextStyle(fontFamily: font, color: _gbLightFg),
      titleMedium: TextStyle(fontFamily: font, color: _gbLightFg),
      titleLarge:  TextStyle(fontFamily: font, color: _gbLightFg),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: _gbLightBlue,
      foregroundColor: Colors.white,
      titleTextStyle: TextStyle(fontFamily: font, fontSize: 18, color: Colors.white),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: _gbLightBg1,
      selectedColor: _gbLightBlue.withValues(alpha: 0.25),
      labelStyle: TextStyle(fontFamily: font, color: _gbLightFg),
    ),
    dividerColor: _gbLightGray.withValues(alpha: 0.4),
  );
}

ThemeData buildDarkTheme(String font) {
  final cs = ColorScheme.dark(
    primary:              _gbDarkAqua,
    onPrimary:            _gbDarkBg,
    primaryContainer:     _gbDarkBg2,
    onPrimaryContainer:   _gbDarkFg,
    secondary:            _gbDarkBlue,
    onSecondary:          _gbDarkBg,
    secondaryContainer:   _gbDarkBg1,
    onSecondaryContainer: _gbDarkFg1,
    tertiary:             _gbDarkOrange,
    error:                _gbDarkRed,
    surface:              _gbDarkBg,
    onSurface:            _gbDarkFg,
    surfaceContainerHighest: _gbDarkBg2,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    fontFamily: font,
    scaffoldBackgroundColor: _gbDarkBg0Hard,
    textTheme: TextTheme(
      bodyMedium:  TextStyle(fontFamily: font, color: _gbDarkFg),
      bodyLarge:   TextStyle(fontFamily: font, color: _gbDarkFg),
      titleMedium: TextStyle(fontFamily: font, color: _gbDarkFg),
      titleLarge:  TextStyle(fontFamily: font, color: _gbDarkFg),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: _gbDarkBg1,
      foregroundColor: _gbDarkFg,
      titleTextStyle: TextStyle(fontFamily: font, fontSize: 18, color: _gbDarkFg),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: _gbDarkBg1,
      selectedColor: _gbDarkAqua.withValues(alpha: 0.3),
      labelStyle: TextStyle(fontFamily: font, color: _gbDarkFg),
    ),
    dividerColor: _gbDarkGray.withValues(alpha: 0.4),
  );
}

ThemeData buildEinkTheme(String font) {
  const black   = Color(0xFF000000);
  const white   = Color(0xFFFFFFFF);
  const gray1   = Color(0xFF333333);
  const gray2   = Color(0xFF777777);
  const gray3   = Color(0xFFBBBBBB);
  const grayBg  = Color(0xFFF0F0F0);

  final cs = ColorScheme.light(
    primary:              black,
    onPrimary:            white,
    primaryContainer:     grayBg,
    onPrimaryContainer:   black,
    secondary:            gray1,
    onSecondary:          white,
    secondaryContainer:   gray3,
    onSecondaryContainer: black,
    tertiary:             gray2,
    error:                gray1,
    surface:              white,
    onSurface:            black,
    surfaceContainerHighest: grayBg,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    fontFamily: font,
    scaffoldBackgroundColor: white,
    textTheme: TextTheme(
      bodyMedium:  TextStyle(fontFamily: font, color: black),
      bodyLarge:   TextStyle(fontFamily: font, color: black),
      titleMedium: TextStyle(fontFamily: font, color: black),
      titleLarge:  TextStyle(fontFamily: font, color: black),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: black,
      foregroundColor: white,
      titleTextStyle: TextStyle(fontFamily: font, fontSize: 18, color: white),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: grayBg,
      selectedColor: gray3,
      labelStyle: TextStyle(fontFamily: font, color: black),
    ),
    dividerColor: gray3,
    splashFactory: NoSplash.splashFactory,
  );
}

class BibleApp extends StatelessWidget {
  const BibleApp({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final font  = state.fontFamily;
    final mode  = state.themeMode;

    final ThemeData theme;
    switch (mode) {
      case 'dark':
        theme = buildDarkTheme(font);
        break;
      case 'eink':
        theme = buildEinkTheme(font);
        break;
      default:
        theme = buildLightTheme(font);
    }

    return MaterialApp(
      title: 'Греческая Библия',
      debugShowCheckedModeBanner: false,
      theme: theme,
      initialRoute: '/',
      routes: {
        '/':            (_) => const MainShell(),
        '/dictionaries': (ctx) => const DictionaryScreen(),
        '/settings':     (_) => const SettingsScreen(),
      },
    );
  }
}
