// lib/main.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/app_state.dart';
import 'core/db/db_service.dart';
import 'core/db/dictionary_service.dart';
import 'core/prefs/prefs_service.dart';

import 'features/home/home_module.dart';
import 'features/dictionary/dictionary_module.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final db    = DBService();
  final prefs = PrefsService();

  await prefs.init();
  await db.init();

  final dictService = DictionaryService(db.dictDb);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => AppState(db: db, prefs: prefs)..initialize(),
        ),
        ChangeNotifierProvider(
          create: (_) => DictionaryProvider(dictService),
        ),
      ],
      child: const BibleApp(),
    ),
  );
}

class BibleApp extends StatelessWidget {
  const BibleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Греческая Библия',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF1B4B8A),
        fontFamily: 'Gentium',
        textTheme: const TextTheme(
          bodyMedium:  TextStyle(fontFamily: 'Gentium'),
          bodyLarge:   TextStyle(fontFamily: 'Gentium'),
          titleMedium: TextStyle(fontFamily: 'Gentium'),
          titleLarge:  TextStyle(fontFamily: 'Gentium'),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1B4B8A),
          foregroundColor: Colors.white,
          titleTextStyle: TextStyle(
            fontFamily: 'Gentium',
            fontSize: 18,
            color: Colors.white,
          ),
        ),
      ),
      initialRoute: '/',
      routes: {
        '/':            (_) => const HomeScreen(),
        '/dictionaries': (ctx) => const DictionaryScreen(),
      },
    );
  }
}
