// lib/core/models/models.dart

class BookModel {
  final int bookNumber;
  final String shortName;
  const BookModel({required this.bookNumber, required this.shortName});
  factory BookModel.fromMap(Map<String, dynamic> map) => BookModel(
        bookNumber: map['book_number'] as int,
        shortName: map['short_name'] as String? ?? '',
      );
}

class WordModel {
  final int chapter;
  final int verse;
  final int wordNumber;
  final String word;
  final String? strongs;
  final String? morphology;

  const WordModel({
    required this.chapter,
    required this.verse,
    required this.wordNumber,
    required this.word,
    this.strongs,
    this.morphology,
  });

  factory WordModel.fromMap(Map<String, dynamic> map) => WordModel(
        chapter:    map['chapter']     as int,
        verse:      map['verse']       as int,
        wordNumber: map['word_number'] as int,
        word:       map['word']        as String? ?? '',
        strongs:    map['strongs']     as String?,
        morphology: map['morphology']  as String?,
      );
}

class VerseModel {
  final int chapter;
  final int verse;
  final List<WordModel> words;
  const VerseModel({required this.chapter, required this.verse, required this.words});
}

class WordDetail {
  final String morphologyText;
  final String definitionHtml;
  const WordDetail({required this.morphologyText, required this.definitionHtml});
}

class ReadingPosition {
  final int bookNumber;
  final int chapter;
  final int verse;
  const ReadingPosition({required this.bookNumber, required this.chapter, required this.verse});
}

class SearchResult {
  final int bookNumber;
  final String bookShortName;
  final int chapter;
  final int verse;
  final String word;
  final String? strongs;
  final String? morphology;

  const SearchResult({
    required this.bookNumber,
    required this.bookShortName,
    required this.chapter,
    required this.verse,
    required this.word,
    this.strongs,
    this.morphology,
  });
}

/// Used by morphology picker
class MorphEntry {
  final String indication;
  final String meaning;
  const MorphEntry({required this.indication, required this.meaning});
  @override
  String toString() => '$indication — $meaning';
}

/// Carries info about which word to highlight/blink after navigation
class HighlightTarget {
  final int chapter;
  final int verse;
  final String? strongs; // if null, highlight whole verse
  const HighlightTarget({required this.chapter, required this.verse, this.strongs});
}

// ── Search term (multi-word) ──────────────────────────────────────────────────
enum SearchTermType { word, strongs }

class SearchTerm {
  final SearchTermType type;
  final String value;
  const SearchTerm({required this.type, required this.value});
}

// ── Dictionary models ─────────────────────────────────────────────────────────

/// Represents a dictionary available in the app (e.g. Strong's, Liddell-Scott).
class DictionaryMeta {
  final String id;        // unique key, e.g. 'strongs_greek'
  final String title;
  final String? description;

  const DictionaryMeta({
    required this.id,
    required this.title,
    this.description,
  });
}

/// A single entry inside a dictionary.
class DictionaryEntry {
  final String term;          // the key / lemma shown as title
  final String definitionHtml; // HTML body (may contain markup from DB)
  final String? strongs;      // optional Strong's number, e.g. 'G1234'

  const DictionaryEntry({
    required this.term,
    required this.definitionHtml,
    this.strongs,
  });

  factory DictionaryEntry.fromMap(Map<String, dynamic> map) => DictionaryEntry(
        term:           map['topic']      as String? ?? '',
        definitionHtml: map['definition'] as String? ?? '',
        strongs:        map['topic']      as String?,
      );
}
