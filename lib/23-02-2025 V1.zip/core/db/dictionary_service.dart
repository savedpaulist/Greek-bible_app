// lib/core/db/dictionary_service.dart
//
// Provides read-only access to the Strong's / morphology dictionary
// stored in the existing СтрДв.dictionary.SQLite3 asset.
//
// The service is intentionally kept thin: it wraps the same Database
// instance that DBService already opened so we avoid opening the file twice.

import 'package:sqflite/sqflite.dart';
import '../models/models.dart';

class DictionaryService {
  final Database _db;

  DictionaryService(this._db);

  // ── Available dictionaries ────────────────────────────────────────────────
  // The current DB contains one logical dictionary (Strong's Greek).
  // Extend this list when more SQLite dictionaries are added.
  List<DictionaryMeta> get availableDictionaries => const [
        DictionaryMeta(
          id: 'strongs_greek',
          title: 'Словарь Стронга (греческий)',
          description: 'Лексикон греческих слов Нового Завета '
              'по системе нумерации Джеймса Стронга.',
        ),
      ];

  // ── Fetch a page of entries ───────────────────────────────────────────────
  /// Returns up to [limit] entries from the dictionary, optionally filtered
  /// by [query] (prefix search on the topic/term column).
  Future<List<DictionaryEntry>> fetchEntries({
    String? query,
    int limit = 50,
    int offset = 0,
  }) async {
    final List<Map<String, dynamic>> rows;

    if (query != null && query.trim().isNotEmpty) {
      final q = query.trim();
      rows = await _db.rawQuery(
        'SELECT topic, definition FROM dictionary '
        'WHERE topic LIKE ? OR definition LIKE ? '
        'ORDER BY topic LIMIT ? OFFSET ?',
        ['%$q%', '%$q%', limit, offset],
      );
    } else {
      rows = await _db.rawQuery(
        'SELECT topic, definition FROM dictionary '
        'ORDER BY topic LIMIT ? OFFSET ?',
        [limit, offset],
      );
    }

    return rows.map(DictionaryEntry.fromMap).toList();
  }

  // ── Fetch single entry by Strong's number ────────────────────────────────
  Future<DictionaryEntry?> fetchByStrongs(String strongs) async {
    final clean = strongs.replaceAll(RegExp(r'^[A-Za-z]+'), '');
    final rows = await _db.rawQuery(
      'SELECT topic, definition FROM dictionary WHERE topic=? LIMIT 1',
      ['G$clean'],
    );
    if (rows.isEmpty) return null;
    return DictionaryEntry.fromMap(rows.first);
  }

  // ── Total count (for pagination) ─────────────────────────────────────────
  Future<int> countEntries({String? query}) async {
    final List<Map<String, dynamic>> rows;
    if (query != null && query.trim().isNotEmpty) {
      final q = query.trim();
      rows = await _db.rawQuery(
        'SELECT COUNT(*) AS cnt FROM dictionary '
        'WHERE topic LIKE ? OR definition LIKE ?',
        ['%$q%', '%$q%'],
      );
    } else {
      rows = await _db.rawQuery('SELECT COUNT(*) AS cnt FROM dictionary');
    }
    return (rows.first['cnt'] as int?) ?? 0;
  }
}
