// lib/db_service.dart
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import "../models/models.dart";

// ── Greek diacritics normalizer ───────────────────────────────────────────────
String normalizeGreek(String s) {
  final buf = StringBuffer();
  for (final rune in s.runes) {
    final ch = String.fromCharCode(rune);
    buf.write(_dMap[ch] ?? ch);
  }
  return buf.toString().toLowerCase();
}

final Map<String, String> _dMap = () {
  final m = <String, String>{};
  void add(List<String> chars, String base) { for (final c in chars) {
    m[c] = base;
  } }
  add(['ά','ά','ἀ','ἁ','ἂ','ἃ','ἄ','ἅ','ἆ','ἇ','ᾀ','ᾁ','ᾂ','ᾃ','ᾄ','ᾅ','ᾆ','ᾇ',
       'ᾰ','ᾱ','ᾲ','ᾳ','ᾴ','ᾶ','ᾷ','Ά','Ά','Ἀ','Ἁ','Ἂ','Ἃ','Ἄ','Ἅ','Ἆ','Ἇ',
       'ᾈ','ᾉ','ᾊ','ᾋ','ᾌ','ᾍ','ᾎ','ᾏ','Ᾰ','Ᾱ','Ὰ','Ά','ᾼ','α','Α'], 'α');
  add(['έ','έ','ἐ','ἑ','ἒ','ἓ','ἔ','ἕ','Έ','Έ','Ἐ','Ἑ','Ἒ','Ἓ','Ἔ','Ἕ','Ὲ','Έ','ε','Ε'], 'ε');
  add(['ή','ή','ἠ','ἡ','ἢ','ἣ','ἤ','ἥ','ἦ','ἧ','ᾐ','ᾑ','ᾒ','ᾓ','ᾔ','ᾕ','ᾖ','ᾗ',
       'ῂ','ῃ','ῄ','ῆ','ῇ','Ή','Ή','Ἠ','Ἡ','Ἢ','Ἣ','Ἤ','Ἥ','Ἦ','Ἧ','ᾘ','ᾙ',
       'ᾚ','ᾛ','ᾜ','ᾝ','ᾞ','ᾟ','Ὴ','Ή','ῌ','η','Η'], 'η');
  add(['ί','ί','ἰ','ἱ','ἲ','ἳ','ἴ','ἵ','ἶ','ἷ','ῐ','ῑ','ῒ','ΐ','ῖ','ῗ',
       'Ί','Ί','Ἰ','Ἱ','Ἲ','Ἳ','Ἴ','Ἵ','Ἶ','Ἷ','Ῐ','Ῑ','Ὶ','Ί','ι','Ι'], 'ι');
  add(['ό','ό','ὀ','ὁ','ὂ','ὃ','ὄ','ὅ','Ό','Ό','Ὀ','Ὁ','Ὂ','Ὃ','Ὄ','Ὅ','Ὸ','Ό','ο','Ο'], 'ο');
  add(['ύ','ύ','ὐ','ὑ','ὒ','ὓ','ὔ','ὕ','ὖ','ὗ','ῠ','ῡ','ῢ','ΰ','ῦ','ῧ',
       'Ύ','Ύ','Ὑ','Ὓ','Ὕ','Ὗ','Ῠ','Ῡ','Ὺ','Ύ','υ','Υ'], 'υ');
  add(['ώ','ώ','ὠ','ὡ','ὢ','ὣ','ὤ','ὥ','ὦ','ὧ','ᾠ','ᾡ','ᾢ','ᾣ','ᾤ','ᾥ','ᾦ','ᾧ',
       'ῲ','ῳ','ῴ','ῶ','ῷ','Ώ','Ώ','Ὠ','Ὡ','Ὢ','Ὣ','Ὤ','Ὥ','Ὦ','Ὧ','ᾨ','ᾩ',
       'ᾪ','ᾫ','ᾬ','ᾭ','ᾮ','ᾯ','Ὼ','Ώ','ῼ','ω','Ω'], 'ω');
  add(['ῤ','ῥ','Ῥ','ρ','Ρ'], 'ρ');
  add(['β','Β'], 'β'); add(['γ','Γ'], 'γ'); add(['δ','Δ'], 'δ');
  add(['ζ','Ζ'], 'ζ'); add(['θ','Θ'], 'θ'); add(['κ','Κ'], 'κ');
  add(['λ','Λ'], 'λ'); add(['μ','Μ'], 'μ'); add(['ν','Ν'], 'ν');
  add(['ξ','Ξ'], 'ξ'); add(['π','Π'], 'π'); add(['σ','ς','Σ'], 'σ');
  add(['τ','Τ'], 'τ'); add(['φ','Φ'], 'φ'); add(['χ','Χ'], 'χ');
  add(['ψ','Ψ'], 'ψ');
  return m;
}();

// ─────────────────────────────────────────────────────────────────────────────
class DBService {
  static const _bibleAsset = 'assets/LXX_BYZ_WORDS_ONLY.SQLite3';
  static const _dictAsset  = 'assets/СтрДв.dictionary.SQLite3';

  Database? _bibleDb;
  Database? _dictDb;
  Database? _indexDb;

  /// Exposes the dictionary database so [DictionaryService] can reuse it.
  Database get dictDb => _dictDb!;

  Future<void> init() async {
    _bibleDb = await _openReadOnly(_bibleAsset, 'bible.db');
    _dictDb  = await _openReadOnly(_dictAsset,  'dict.db');
  }

  Future<Database> _openReadOnly(String asset, String filename) async {
    final path = join(await getDatabasesPath(), filename);
    if (!File(path).existsSync()) {
      final data = await rootBundle.load(asset);
      await File(path).writeAsBytes(data.buffer.asUint8List(), flush: true);
    }
    return openDatabase(path, readOnly: true);
  }

  // ── Books ──────────────────────────────────────────────────────────────────
  Future<List<BookModel>> getBooks() async {
    final rows = await _bibleDb!.rawQuery(
        'SELECT book_number, short_name FROM books ORDER BY book_number');
    return rows.map(BookModel.fromMap).toList();
  }

  // ── All words of a book ────────────────────────────────────────────────────
  Future<List<WordModel>> getWords(int bookNumber) async {
    final rows = await _bibleDb!.rawQuery(
        'SELECT chapter, verse, word_number, word, strongs, morphology '
        'FROM words WHERE book_number=? ORDER BY chapter, verse, word_number',
        [bookNumber]);
    return rows.map(WordModel.fromMap).toList();
  }

  // ── Words of one verse ─────────────────────────────────────────────────────
  Future<List<WordModel>> getVerseWords(int book, int ch, int v) async {
    final rows = await _bibleDb!.rawQuery(
        'SELECT chapter, verse, word_number, word, strongs, morphology '
        'FROM words WHERE book_number=? AND chapter=? AND verse=? ORDER BY word_number',
        [book, ch, v]);
    return rows.map(WordModel.fromMap).toList();
  }

  // ── Group flat word list into VerseModel list ─────────────────────────────
  List<VerseModel> groupIntoVerses(List<WordModel> words) {
    final map = <String, VerseModel>{};
    for (final w in words) {
      final k = '${w.chapter}_${w.verse}';
      if (!map.containsKey(k)) {
        map[k] = VerseModel(chapter: w.chapter, verse: w.verse, words: []);
      }
      (map[k]!.words).add(w);
    }
    return map.values.toList()
      ..sort((a, b) {
        final c = a.chapter.compareTo(b.chapter);
        return c != 0 ? c : a.verse.compareTo(b.verse);
      });
  }

  // ── Strong's definition ────────────────────────────────────────────────────
  Future<String?> getStrongsDefinition(String strongs) async {
    final clean = strongs.replaceAll(RegExp(r'^[A-Za-z]+'), '');
    final rows  = await _dictDb!.rawQuery(
        'SELECT definition FROM dictionary WHERE topic=? LIMIT 1', ['G$clean']);
    return rows.isEmpty ? null : rows.first['definition'] as String?;
  }

  // ── Morphology ─────────────────────────────────────────────────────────────
  Future<String> getMorphologyText(String morphology) async {
    final db      = _dictDb!;
    final results = <String>[];

    Future<String?> lookup(String code) async {
      final rows = await db.rawQuery(
          'SELECT meaning FROM morphology_indications WHERE indication=? LIMIT 1',
          [code]);
      return rows.isEmpty ? null : rows.first['meaning'] as String?;
    }

    final full = await lookup(morphology);
    if (full != null) return full;

    final rawParts = morphology.split('-');
    int segIdx = 0;
    for (final seg in rawParts) {
      if (seg.isEmpty) continue;
      final ind = segIdx == 0 ? seg : '-$seg';
      segIdx++;

      final m = await lookup(ind);
      if (m != null && m.isNotEmpty) { results.add(m); continue; }

      if (seg.length > 1) {
        bool found = false;
        for (int len = 1; len < seg.length && !found; len++) {
          final sub = segIdx == 1 ? seg.substring(0, len) : '-${seg.substring(0, len)}';
          final sm  = await lookup(sub);
          if (sm != null && sm.isNotEmpty) { results.add(sm); found = true; }
        }
        if (!found && seg.length >= 2) {
          final suf = '-${seg.substring(seg.length - 2)}';
          final sm  = await lookup(suf);
          if (sm != null && sm.isNotEmpty) results.add(sm);
        }
      }
    }
    return results.isEmpty ? morphology : results.join(', ');
  }

  // ── Word detail ────────────────────────────────────────────────────────────
  Future<WordDetail> getWordDetail(WordModel word) async {
    final morph = (word.morphology?.isNotEmpty ?? false)
        ? await getMorphologyText(word.morphology!) : '';
    final def   = (word.strongs?.isNotEmpty ?? false)
        ? await getStrongsDefinition(word.strongs!) ?? '<p>Нет данных</p>'
        : '<p>Нет данных</p>';
    return WordDetail(morphologyText: morph, definitionHtml: def);
  }

  // ── Morphology picker ──────────────────────────────────────────────────────
  Future<List<MorphEntry>> getFirstLevelMorphCodes() async {
    final rows = await _dictDb!.rawQuery(
        "SELECT indication, meaning FROM morphology_indications "
        "WHERE indication NOT LIKE '-%' ORDER BY indication");
    return rows.map((r) => MorphEntry(
        indication: r['indication'] as String,
        meaning: r['meaning'] as String? ?? '')).toList();
  }

  Future<List<MorphEntry>> getSecondLevelMorphCodes() async {
    final rows = await _dictDb!.rawQuery(
        "SELECT indication, meaning FROM morphology_indications "
        "WHERE indication LIKE '-%' ORDER BY indication");
    return rows.map((r) => MorphEntry(
        indication: r['indication'] as String,
        meaning: r['meaning'] as String? ?? '')).toList();
  }

  // ── FTS index ──────────────────────────────────────────────────────────────
  Future<void> buildIndex({void Function(double)? onProgress}) async {
    final path = join(await getDatabasesPath(), 'search_index.db');
    if (File(path).existsSync()) await File(path).delete();

    _indexDb = await openDatabase(path, version: 3, onCreate: (db, _) async {
      await db.execute('''
        CREATE VIRTUAL TABLE IF NOT EXISTS words_fts
        USING fts4(book_number INTEGER, chapter INTEGER, verse INTEGER,
                   word TEXT, word_norm TEXT, strongs TEXT, morphology TEXT)''');
      await db.execute('''
        CREATE TABLE IF NOT EXISTS books_cache(
          book_number INTEGER PRIMARY KEY, short_name TEXT)''');
    });

    final books = await getBooks();
    await _indexDb!.delete('books_cache');
    final bb = _indexDb!.batch();
    for (final b in books) {
      bb.insert('books_cache',
          {'book_number': b.bookNumber, 'short_name': b.shortName});
    }
    await bb.commit(noResult: true);

    final words = await _bibleDb!.rawQuery(
        'SELECT book_number, chapter, verse, word, strongs, morphology FROM words');
    final total = words.length;
    const chunk = 2000;

    for (int start = 0; start < total; start += chunk) {
      final end   = (start + chunk).clamp(0, total);
      final batch = _indexDb!.batch();
      for (int i = start; i < end; i++) {
        final w  = words[i];
        final ws = w['word'] as String? ?? '';
        batch.rawInsert(
            'INSERT INTO words_fts'
            '(book_number,chapter,verse,word,word_norm,strongs,morphology)'
            ' VALUES(?,?,?,?,?,?,?)',
            [w['book_number'], w['chapter'], w['verse'],
             ws, normalizeGreek(ws), w['strongs'], w['morphology']]);
      }
      await batch.commit(noResult: true);
      onProgress?.call(end / total);
    }
  }

  // ── Search ─────────────────────────────────────────────────────────────────
  Future<List<SearchResult>> searchByWord(String query) async {
    await _ensureIndex();
    final norm = normalizeGreek(query.trim());
    try {
      final rows = await _indexDb!.rawQuery(_sel('word_norm MATCH ?'), ['$norm*']);
      if (rows.isNotEmpty) return _map(rows);
    } catch (_) {}
    return _likeFallback('word_norm', norm);
  }

  Future<List<SearchResult>> searchMultiTerm(List<SearchTerm> terms) async {
    await _ensureIndex();
    if (terms.isEmpty) return [];

    final conditions = <String>[];
    final args       = <dynamic>[];

    for (final t in terms) {
      if (t.type == SearchTermType.strongs) {
        final clean = t.value.replaceAll(RegExp(r'^[GgА-Яа-я]+'), '');
        conditions.add('EXISTS (SELECT 1 FROM words_fts x '
            'WHERE x.book_number=w.book_number AND x.chapter=w.chapter '
            'AND x.verse=w.verse AND x.strongs=?)');
        args.add(clean);
      } else {
        final norm = normalizeGreek(t.value);
        conditions.add('EXISTS (SELECT 1 FROM words_fts x '
            'WHERE x.book_number=w.book_number AND x.chapter=w.chapter '
            'AND x.verse=w.verse AND x.word_norm LIKE ?)');
        args.add('%$norm%');
      }
    }

    final sql = '''
      SELECT DISTINCT w.book_number, b.short_name, w.chapter, w.verse,
             w.word, w.strongs, w.morphology
      FROM words_fts w
      LEFT JOIN books_cache b ON b.book_number = w.book_number
      WHERE ${conditions.join(' AND ')}
      LIMIT 300
    ''';

    try {
      return _map(await _indexDb!.rawQuery(sql, args));
    } catch (_) {
      return [];
    }
  }

  Future<List<SearchResult>> searchByStrongs(String s) async {
    await _ensureIndex();
    final clean = s.trim().replaceAll(RegExp(r'^[GgА-Яа-я]+'), '');
    try {
      final rows = await _indexDb!.rawQuery(_sel('strongs MATCH ?'), [clean]);
      if (rows.isNotEmpty) return _map(rows);
    } catch (_) {}
    return _likeFallback('strongs', clean);
  }

  Future<List<SearchResult>> searchByMorphology(String morph) async {
    await _ensureIndex();
    try {
      final rows =
          await _indexDb!.rawQuery(_sel('morphology MATCH ?'), [morph.trim()]);
      return _map(rows);
    } catch (_) {
      return _likeFallback('morphology', morph.trim());
    }
  }

  String _sel(String where) => '''
    SELECT w.book_number, b.short_name, w.chapter, w.verse,
           w.word, w.strongs, w.morphology
    FROM words_fts w
    LEFT JOIN books_cache b ON b.book_number = w.book_number
    WHERE $where LIMIT 300''';

  Future<List<SearchResult>> _likeFallback(String col, String q) async {
    await _ensureIndex();
    final rows = await _indexDb!.rawQuery(_sel('$col LIKE ?'), ['%$q%']);
    return _map(rows);
  }

  List<SearchResult> _map(List<Map<String, dynamic>> rows) =>
      rows.map((r) => SearchResult(
            bookNumber:    r['book_number'] as int,
            bookShortName: r['short_name'] as String? ?? '',
            chapter:       r['chapter']    as int,
            verse:         r['verse']      as int,
            word:          r['word']       as String? ?? '',
            strongs:       r['strongs']    as String?,
            morphology:    r['morphology'] as String?,
          )).toList();

  Future<void> _ensureIndex() async {
    if (_indexDb != null) return;
    final path = join(await getDatabasesPath(), 'search_index.db');
    _indexDb   = await openDatabase(path);
  }

  void dispose() {
    _bibleDb?.close();
    _dictDb?.close();
    _indexDb?.close();
  }
}
