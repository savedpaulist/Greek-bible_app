// lib/features/dictionary/provider/dictionary_provider.dart

import 'package:flutter/foundation.dart';
import '../../../core/db/dictionary_service.dart';
import '../../../core/models/models.dart';

class DictionaryProvider extends ChangeNotifier {
  final DictionaryService _service;

  DictionaryProvider(this._service) {
    _init();
  }

  // ── State ────────────────────────────────────────────────────────────────
  List<DictionaryMeta> get dictionaries => _service.availableDictionaries;

  List<DictionaryEntry> entries    = [];
  bool   isLoading                  = false;
  bool   isLoadingMore              = false;
  String? error;

  String _query            = '';
  int    _offset           = 0;
  int    _total            = 0;
  bool   get hasMore       => entries.length < _total;
  String get currentQuery  => _query;

  static const _pageSize = 50;

  // ── Init ─────────────────────────────────────────────────────────────────
  Future<void> _init() async {
    await loadEntries();
  }

  // ── Load / search ─────────────────────────────────────────────────────────
  Future<void> loadEntries({String query = ''}) async {
    _query   = query;
    _offset  = 0;
    entries  = [];
    error    = null;
    isLoading = true;
    notifyListeners();

    try {
      _total  = await _service.countEntries(query: query.isEmpty ? null : query);
      entries = await _service.fetchEntries(
        query: query.isEmpty ? null : query,
        limit:  _pageSize,
        offset: 0,
      );
      _offset = entries.length;
    } catch (e) {
      error = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  /// Appends the next page of results (called when the list scrolls near the end).
  Future<void> loadMore() async {
    if (isLoadingMore || !hasMore) return;
    isLoadingMore = true;
    notifyListeners();

    try {
      final next = await _service.fetchEntries(
        query:  _query.isEmpty ? null : _query,
        limit:  _pageSize,
        offset: _offset,
      );
      entries  = [...entries, ...next];
      _offset += next.length;
    } catch (e) {
      debugPrint('DictionaryProvider.loadMore: $e');
    } finally {
      isLoadingMore = false;
      notifyListeners();
    }
  }

  // ── Lookup by Strong's number ─────────────────────────────────────────────
  Future<DictionaryEntry?> lookupStrongs(String strongs) =>
      _service.fetchByStrongs(strongs);
}
