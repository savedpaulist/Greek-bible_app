// lib/features/dictionary/view/dictionary_detail_screen.dart
//
// Shows a searchable, paginated list of [DictionaryEntry] items for one
// dictionary. Tapping an entry opens an inline bottom sheet with the full
// definition rendered as styled HTML text.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/models/models.dart';
import '../provider/dictionary_provider.dart';
import '../widgets/dictionary_entry_tile.dart';

class DictionaryDetailScreen extends StatefulWidget {
  const DictionaryDetailScreen({super.key, required this.dictionaryId});

  final String dictionaryId;

  @override
  State<DictionaryDetailScreen> createState() => _DictionaryDetailScreenState();
}

class _DictionaryDetailScreenState extends State<DictionaryDetailScreen> {
  final _searchCtrl   = TextEditingController();
  final _scrollCtrl   = ScrollController();
  bool  _searchActive = false;

  @override
  void initState() {
    super.initState();
    _scrollCtrl.addListener(_onScroll);
    // Kick off the initial load (no query)
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DictionaryProvider>().loadEntries();
    });
  }

  void _onScroll() {
    if (_scrollCtrl.position.extentAfter < 200) {
      context.read<DictionaryProvider>().loadMore();
    }
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _runSearch(String q) {
    context.read<DictionaryProvider>().loadEntries(query: q);
  }

  void _clearSearch() {
    _searchCtrl.clear();
    _runSearch('');
    setState(() => _searchActive = false);
  }

  // ── Entry detail bottom sheet ────────────────────────────────────────────
  void _showEntry(BuildContext context, DictionaryEntry entry) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.6,
        maxChildSize: 0.95,
        minChildSize: 0.3,
        builder: (_, scrollCtrl) => _EntryDetailSheet(
          entry: entry,
          scrollController: scrollCtrl,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<DictionaryProvider>();

    return Scaffold(
      appBar: AppBar(
        title: _searchActive
            ? TextField(
                controller: _searchCtrl,
                autofocus: true,
                style: const TextStyle(color: Colors.white),
                cursorColor: Colors.white,
                decoration: const InputDecoration(
                  hintText: 'Поиск по слову или номеру…',
                  hintStyle: TextStyle(color: Colors.white54),
                  border: InputBorder.none,
                ),
                onChanged: _runSearch,
              )
            : const Text('Словарь Стронга'),
        actions: [
          if (_searchActive)
            IconButton(
              icon: const Icon(Icons.close),
              tooltip: 'Сбросить поиск',
              onPressed: _clearSearch,
            )
          else
            IconButton(
              icon: const Icon(Icons.search),
              tooltip: 'Поиск',
              onPressed: () => setState(() => _searchActive = true),
            ),
        ],
      ),
      body: _buildBody(provider),
    );
  }

  Widget _buildBody(DictionaryProvider provider) {
    if (provider.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (provider.error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48, color: Colors.red),
            const SizedBox(height: 12),
            Text(provider.error!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => provider.loadEntries(query: provider.currentQuery),
              child: const Text('Повторить'),
            ),
          ],
        ),
      );
    }

    if (provider.entries.isEmpty) {
      return Center(
        child: Text(
          'Ничего не найдено',
          style: Theme.of(context).textTheme.bodyLarge,
        ),
      );
    }

    return ListView.separated(
      controller: _scrollCtrl,
      itemCount: provider.entries.length + (provider.isLoadingMore ? 1 : 0),
      separatorBuilder: (_, __) => const Divider(height: 1, indent: 16),
      itemBuilder: (context, i) {
        if (i >= provider.entries.length) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final entry = provider.entries[i];
        return DictionaryEntryTile(
          entry: entry,
          onTap: () => _showEntry(context, entry),
        );
      },
    );
  }
}

// ── Entry detail sheet ────────────────────────────────────────────────────────
class _EntryDetailSheet extends StatelessWidget {
  const _EntryDetailSheet({
    required this.entry,
    required this.scrollController,
  });

  final DictionaryEntry  entry;
  final ScrollController scrollController;

  // Very basic HTML → plain-text renderer.
  // Replace with flutter_html if richer rendering is needed.
  static String _render(String html) {
    return html
        .replaceAll(RegExp(r'<br\s*/?>',  caseSensitive: false), '\n')
        .replaceAll(RegExp(r'<p[^>]*>',   caseSensitive: false), '\n')
        .replaceAll(RegExp(r'</p>',        caseSensitive: false), '\n')
        .replaceAll(RegExp(r'<[^>]+>'),    '')
        .replaceAll(RegExp(r'\n{3,}'),     '\n\n')
        .trim();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      children: [
        // Drag handle
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Container(
            width: 40, height: 4,
            decoration: BoxDecoration(
              color: theme.colorScheme.outlineVariant,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ),
        // Strong's number header
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  entry.term,
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: theme.colorScheme.onPrimaryContainer,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Gentium',
                  ),
                ),
              ),
            ],
          ),
        ),
        const Divider(),
        // Scrollable definition body
        Expanded(
          child: ListView(
            controller: scrollController,
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              Text(
                _render(entry.definitionHtml),
                style: theme.textTheme.bodyMedium?.copyWith(
                  height: 1.6,
                  fontFamily: 'Gentium',
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
