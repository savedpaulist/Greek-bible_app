// lib/features/dictionary/view/dictionary_screen.dart
//
// Entry point for the «Словари» feature.
// Shows the list of available dictionaries; tapping one opens
// DictionaryDetailScreen.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../provider/dictionary_provider.dart';
import '../widgets/dictionary_tile.dart';
import 'dictionary_detail_screen.dart';

class DictionaryScreen extends StatelessWidget {
  const DictionaryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<DictionaryProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Словари'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: provider.dictionaries.length,
        itemBuilder: (context, index) {
          final dict = provider.dictionaries[index];
          return DictionaryTile(
            dictionary: dict,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ChangeNotifierProvider.value(
                  value: provider,
                  child: DictionaryDetailScreen(dictionaryId: dict.id),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
