// lib/features/dictionary/dictionary_module.dart
//
// Public API of the Dictionary feature module.
// Import only this file from main.dart or the router.

export 'view/dictionary_screen.dart';
export 'view/dictionary_detail_screen.dart';
export 'provider/dictionary_provider.dart';
