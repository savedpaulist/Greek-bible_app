// lib/prefs_service.dart
import 'package:shared_preferences/shared_preferences.dart';
import "../models/models.dart";

class PrefsService {
  static const _kFontSize      = 'font_size';
  static const _kBook          = 'book_number';
  static const _kChapter       = 'chapter';
  static const _kVerse         = 'verse';
  static const _kIndexBuilt    = 'fts_index_built';
  static const _kScrollDown    = 'hotkey_scroll_down';
  static const _kScrollUp      = 'hotkey_scroll_up';
  static const _kAnimations    = 'animations_enabled';

  late SharedPreferences _p;
  Future<void> init() async => _p = await SharedPreferences.getInstance();

  double get fontSize          => _p.getDouble(_kFontSize)    ?? 20.0;
  Future<void> setFontSize(double v) => _p.setDouble(_kFontSize, v);

  bool   get animationsEnabled  => _p.getBool(_kAnimations)   ?? true;
  Future<void> setAnimationsEnabled(bool v) => _p.setBool(_kAnimations, v);

  ReadingPosition get position => ReadingPosition(
    bookNumber: _p.getInt(_kBook)    ?? 1,
    chapter:    _p.getInt(_kChapter) ?? 1,
    verse:      _p.getInt(_kVerse)   ?? 1,
  );
  void savePosition(int book, int ch, int verse) {
    _p.setInt(_kBook, book);
    _p.setInt(_kChapter, ch);
    _p.setInt(_kVerse, verse);
  }

  bool get isIndexBuilt => _p.getBool(_kIndexBuilt) ?? false;
  Future<void> setIndexBuilt(bool value)   => _p.setBool(_kIndexBuilt, value);
  Future<void> clearIndexBuilt() => _p.setBool(_kIndexBuilt, false);

  int  get scrollDownKeyId => _p.getInt(_kScrollDown) ?? 0;
  int  get scrollUpKeyId   => _p.getInt(_kScrollUp)   ?? 0;
  Future<void> setScrollDownKeyId(int id) => _p.setInt(_kScrollDown, id);
  Future<void> setScrollUpKeyId(int id)   => _p.setInt(_kScrollUp,   id);
}
