// lib/core/db/dictionary_service.dart
//
// Читает данные из любого из четырёх словарных SQLite-файлов.
// Каждый словарь идентифицируется строковым id (совпадает с DictionaryMeta.id
// и ключами в DBService.dictDbs).
//
// Все четыре базы имеют таблицу: dictionary(topic TEXT, definition TEXT).

import 'package:sqflite/sqflite.dart';
import '../models/models.dart';

class DictionaryService {
  final Map<String, Database> _dbs;
  DictionaryService(this._dbs);

  // ── Список доступных словарей ─────────────────────────────────────────────
  List<DictionaryMeta> get availableDictionaries => [
        const DictionaryMeta(
          id: 'strongs',
          title: 'Словарь Стронга (СтрДв)',
          description: 'Лексикон греческих слов НЗ с леммой и транслитерацией.',
        ),
        const DictionaryMeta(
          id: 'bdag3',
          title: 'BDAG (3-е изд.)',
          description: 'Bauer–Danker–Arndt–Gingrich. Авторитетный '
              'греческо-английский лексикон НЗ.',
        ),
        const DictionaryMeta(
          id: 'tdnt',
          title: 'TDNT',
          description: 'Theological Dictionary of the New Testament '
              '(Kittel & Friedrich). Богословский анализ терминов.',
        ),
        const DictionaryMeta(
          id: 'cbtel',
          title: 'CBTEL',
          description: 'Cyclopædia of Biblical, Theological and Ecclesiastical '
              'Literature (McClintock & Strong).',
        ),
      ].where((m) => _dbs.containsKey(m.id)).toList();

  // ── Страница записей ──────────────────────────────────────────────────────
  Future<List<DictionaryEntry>> fetchEntries({
    required String dictionaryId,
    String? query,
    int limit  = 50,
    int offset = 0,
  }) async {
    final db = _dbs[dictionaryId];
    if (db == null) return [];

    final List<Map<String, dynamic>> rows;
    if (query != null && query.trim().isNotEmpty) {
      final q = query.trim();
      rows = await db.rawQuery(
        'SELECT topic, definition FROM dictionary '
        'WHERE topic LIKE ? OR definition LIKE ? '
        'ORDER BY topic LIMIT ? OFFSET ?',
        ['%$q%', '%$q%', limit, offset],
      );
    } else {
      rows = await db.rawQuery(
        'SELECT topic, definition FROM dictionary '
        'ORDER BY topic LIMIT ? OFFSET ?',
        [limit, offset],
      );
    }
    return rows.map(DictionaryEntry.fromMap).toList();
  }

  // ── Количество (для пагинации) ────────────────────────────────────────────
  Future<int> countEntries({
    required String dictionaryId,
    String? query,
  }) async {
    final db = _dbs[dictionaryId];
    if (db == null) return 0;

    final List<Map<String, dynamic>> rows;
    if (query != null && query.trim().isNotEmpty) {
      final q = query.trim();
      rows = await db.rawQuery(
        'SELECT COUNT(*) AS cnt FROM dictionary '
        'WHERE topic LIKE ? OR definition LIKE ?',
        ['%$q%', '%$q%'],
      );
    } else {
      rows = await db.rawQuery('SELECT COUNT(*) AS cnt FROM dictionary');
    }
    return (rows.first['cnt'] as int?) ?? 0;
  }

  // ── Поиск по Стронгу (только словарь strongs) ────────────────────────────
  Future<DictionaryEntry?> fetchByStrongs(String strongs) async {
    final db = _dbs['strongs'];
    if (db == null) return null;
    final clean = strongs.replaceAll(RegExp(r'^[A-Za-z]+'), '');
    final rows  = await db.rawQuery(
      'SELECT topic, definition FROM dictionary WHERE topic=? LIMIT 1',
      ['G$clean'],
    );
    if (rows.isEmpty) return null;
    return DictionaryEntry.fromMap(rows.first);
  }
}
