// lib/app_state.dart
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'models/models.dart';
import 'db/db_service.dart';
import 'prefs/prefs_service.dart';

class AppState extends ChangeNotifier {
  final DBService    db;
  final PrefsService prefs;

  AppState({required this.db, required this.prefs});

  // ── Данные ────────────────────────────────────────────────────────────────
  List<BookModel>  books     = [];
  List<VerseModel> _verses   = [];
  List<VerseModel> get verses => _verses;

  List<int> get allChapters =>
      _verses.map((v) => v.chapter).toSet().toList()..sort();

  // ── Текущая позиция ───────────────────────────────────────────────────────
  int currentBook    = 1;
  int currentChapter = 1;
  int currentVerse   = 1;

  // Сигнал для HomeScreen: когда меняется — нужен скролл к currentChapter:currentVerse
  int navVersion = 0;

  // ── Highlight (мигание слова после перехода по ссылке) ───────────────────
  HighlightTarget? highlightTarget;

  // ── Настройки ─────────────────────────────────────────────────────────────
  double fontSize          = 20.0;
  bool   animationsEnabled = true;
  int    scrollDownKeyId   = 0;
  int    scrollUpKeyId     = 0;

  // ── Флаги загрузки ────────────────────────────────────────────────────────
  bool   isLoadingBooks = true;
  bool   isLoadingText  = false;
  bool   isIndexing     = false;
  double indexProgress  = 0.0;
  String? error;

  // ── Инициализация ─────────────────────────────────────────────────────────
  Future<void> initialize() async {
    fontSize          = prefs.fontSize;
    animationsEnabled = prefs.animationsEnabled;
    scrollDownKeyId   = prefs.scrollDownKeyId;
    scrollUpKeyId     = prefs.scrollUpKeyId;

    final pos      = prefs.position;
    currentBook    = pos.bookNumber;
    currentChapter = pos.chapter;
    currentVerse   = pos.verse;

    await loadBooks();
    await loadBook(currentBook);

    if (!prefs.isIndexBuilt) _buildIndex();
  }

  // ── Список книг ───────────────────────────────────────────────────────────
  Future<void> loadBooks() async {
    isLoadingBooks = true;
    notifyListeners();
    try {
      books = await db.getBooks();
    } catch (e) {
      error = e.toString();
    } finally {
      isLoadingBooks = false;
      notifyListeners();
    }
  }

  // ── Загрузка книги ─────────────────────────────────────────────────────────
  // [silent] = true используется из пикера: данные загружаются для показа
  // списка глав, но скролл в HomeScreen НЕ должен срабатывать.
  Future<void> loadBook(int bookNumber, {bool silent = false}) async {
    isLoadingText = true;
    error         = null;
    notifyListeners();
    try {
      currentBook = bookNumber;
      final words = await db.getWords(bookNumber);
      _verses     = db.groupIntoVerses(words);

      // Если текущая глава/стих не входят в загруженную книгу — сброс
      final chapters = allChapters;
      if (chapters.isNotEmpty && !chapters.contains(currentChapter)) {
        currentChapter = chapters.first;
        currentVerse   = 1;
      }

      if (!silent) navVersion++;
    } catch (e) {
      error = e.toString();
    } finally {
      isLoadingText = false;
      notifyListeners();
    }
  }

  // ── Выбор главы и стиха из пикера ─────────────────────────────────────────
  void selectChapterAndVerse(int chapter, int verse) {
    currentChapter  = chapter;
    currentVerse    = verse;
    highlightTarget = null;
    navVersion++;
    _savePosition();
    notifyListeners();
  }

  // ── Переход по ссылке (поиск, словарь) ────────────────────────────────────
  // named param: highlightStrongs — для совместимости с search_screen.dart
  Future<void> navigateToVerse(
    int bookNumber,
    int chapter,
    int verse, {
    String? highlightStrongs,
  }) async {
    if (highlightStrongs != null) {
      highlightTarget = HighlightTarget(
        chapter: chapter,
        verse:   verse,
        strongs: highlightStrongs,
      );
    }

    currentChapter = chapter;
    currentVerse   = verse;

    if (bookNumber != currentBook) {
      // loadBook сам делает navVersion++ и notifyListeners()
      await loadBook(bookNumber);
    } else {
      navVersion++;
      notifyListeners();
    }

    _savePosition();
  }

  void clearHighlight() {
    highlightTarget = null;
    notifyListeners();
  }

  // ── Трекинг видимого стиха (из scroll listener) ───────────────────────────
  // НЕ меняет navVersion — это не навигация, просто обновление позиции
  void updateVisibleVerse(int chapter, int verse) {
    if (chapter == currentChapter && verse == currentVerse) return;
    currentChapter = chapter;
    currentVerse   = verse;
    _savePosition();
    notifyListeners();
  }

  void _savePosition() {
    prefs.savePosition(currentBook, currentChapter, currentVerse);
  }

  // ── Настройки ─────────────────────────────────────────────────────────────
  void setFontSize(double size) {
    fontSize = size.clamp(10.0, 40.0);
    prefs.setFontSize(fontSize);
    notifyListeners();
  }

  void setAnimations(bool enabled) {
    animationsEnabled = enabled;
    prefs.setAnimationsEnabled(enabled);
    notifyListeners();
  }

  void setScrollDownKey(int id) {
    scrollDownKeyId = id;
    prefs.setScrollDownKeyId(id);
    notifyListeners();
  }

  void setScrollUpKey(int id) {
    scrollUpKeyId = id;
    prefs.setScrollUpKeyId(id);
    notifyListeners();
  }

  bool isScrollDownKey(LogicalKeyboardKey k) =>
      scrollDownKeyId != 0 && k.keyId == scrollDownKeyId;
  bool isScrollUpKey(LogicalKeyboardKey k) =>
      scrollUpKeyId != 0 && k.keyId == scrollUpKeyId;

  // Заглушки — windowManager больше не используется
  void expandWindowBackward() {}
  void expandWindowForward()  {}

  // ── Поисковый индекс ─────────────────────────────────────────────────────
  Future<void> _buildIndex() async {
    isIndexing    = true;
    indexProgress = 0;
    notifyListeners();
    try {
      await db.buildIndex(onProgress: (p) {
        indexProgress = p;
        notifyListeners();
      });
      await prefs.setIndexBuilt(true);
    } catch (e) {
      debugPrint('Index error: $e');
    } finally {
      isIndexing = false;
      notifyListeners();
    }
  }

  Future<void> rebuildIndex() async {
    await prefs.clearIndexBuilt();
    await _buildIndex();
  }

}
