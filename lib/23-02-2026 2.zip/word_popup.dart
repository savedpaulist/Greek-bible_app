// lib/word_popup.dart

import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'core/models/models.dart';
import 'core/db/db_service.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Убираем секцию «Ссылки» из превью (она остаётся в полной статье)
// ─────────────────────────────────────────────────────────────────────────────
String _truncateAtLinks(String html) {
  final idx = html.indexOf(RegExp(r'Ссылки', caseSensitive: false));
  return idx >= 0 ? html.substring(0, idx) : html;
}

// ── Парсинг ссылки вида "B:540 4:1" → (book=540, chapter=4, verse=1) ─────────
_BibleRef? _parseBibleHref(String href) {
  if (!href.startsWith('B:')) return null;
  final body     = href.substring(2).trim();
  final spaceIdx = body.indexOf(' ');
  if (spaceIdx < 0) return null;
  final rest     = body.substring(spaceIdx + 1);
  final colonIdx = rest.indexOf(':');
  if (colonIdx < 0) return null;
  final book    = int.tryParse(body.substring(0, spaceIdx));
  final chapter = int.tryParse(rest.substring(0, colonIdx));
  final verse   = int.tryParse(rest.substring(colonIdx + 1));
  if (book == null || chapter == null || verse == null) return null;
  return _BibleRef(book, chapter, verse);
}

class _BibleRef {
  final int book, chapter, verse;
  const _BibleRef(this.book, this.chapter, this.verse);
}

typedef BibleLinkCallback = void Function(int book, int chapter, int verse);

// ─────────────────────────────────────────────────────────────────────────────
// Быстрый попап над словом
// ─────────────────────────────────────────────────────────────────────────────
class WordQuickView extends StatefulWidget {
  final WordModel          word;
  final DBService          db;
  final double             fontSize;
  final VoidCallback       onClose;       // убрать Overlay
  final BibleLinkCallback? onBibleLink;   // перейти по ссылке

  const WordQuickView({
    super.key,
    required this.word,
    required this.db,
    required this.fontSize,
    required this.onClose,
    this.onBibleLink,
  });

  @override
  State<WordQuickView> createState() => _WordQuickViewState();
}

class _WordQuickViewState extends State<WordQuickView> {
  WordDetail? _detail;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final detail = await widget.db.getWordDetail(widget.word);
    if (mounted) setState(() { _detail = detail; _loading = false; });
  }

  // ── Открыть полную статью ─────────────────────────────────────────────────
  // БАГ БЫЛ ЗДЕСЬ: widget.onClose() деактивировал context, после чего
  // showModalBottomSheet падал с «deactivated widget's ancestor».
  // Исправление: сначала открываем bottom sheet (context ещё живой),
  // overlay закрываем через then() — когда sheet всё равно на экране.
  void _openFullScreen() {
    if (_detail == null || !mounted) return;

    // Сохраняем колбэки ДО вызова onClose, т.к. widget может быть disposed
    final onBibleLink = widget.onBibleLink;
    final onClose     = widget.onClose;
    final detail      = _detail!;
    final word        = widget.word;
    final fontSize    = widget.fontSize;

    // 1. Сначала показываем bottom sheet — context ещё активен
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => WordFullView(
        word:        word,
        detail:      detail,
        fontSize:    fontSize,
        onBibleLink: onBibleLink,
      ),
    );

    // 2. Теперь убираем overlay — bottom sheet уже открыт и живёт независимо
    onClose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 8,
      borderRadius: BorderRadius.circular(12),
      color: Theme.of(context).colorScheme.surface,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 340, maxHeight: 260),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer,
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(12)),
              ),
              child: Row(children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Словарная форма (лемма), как только загрузилась
                      Text(
                        _loading
                            ? widget.word.word
                            : (_detail?.lexeme ?? widget.word.word),
                        style: TextStyle(
                          fontFamily: 'Gentium',
                          fontSize: widget.fontSize,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                        ),
                      ),
                      // Форма в тексте, если она отличается от словарной
                      if (!_loading &&
                          _detail?.lexeme != null &&
                          _detail!.lexeme != widget.word.word)
                        Text(
                          widget.word.word,
                          style: TextStyle(
                            fontFamily: 'Gentium',
                            fontSize: widget.fontSize - 4,
                            fontStyle: FontStyle.italic,
                            color: Theme.of(context)
                                .colorScheme
                                .onPrimaryContainer
                                .withOpacity(0.7),
                          ),
                        ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.open_in_full, size: 18),
                  tooltip: 'Развернуть',
                  onPressed: _openFullScreen,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                ),
                const SizedBox(width: 10),
                IconButton(
                  icon: const Icon(Icons.close, size: 18),
                  tooltip: 'Закрыть',
                  onPressed: widget.onClose,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                ),
              ]),
            ),

            // Body
            if (_loading)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: CircularProgressIndicator()),
              )
            else
              Flexible(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (_detail!.morphologyText.isNotEmpty) ...[
                        Text(
                          _detail!.morphologyText,
                          style: TextStyle(
                            fontStyle: FontStyle.italic,
                            fontSize: widget.fontSize - 3,
                            color: Theme.of(context).colorScheme.secondary,
                          ),
                        ),
                        const SizedBox(height: 6),
                      ],
                      GestureDetector(
                        onTap: _openFullScreen,
                        child: Html(
                          data: _truncateAtLinks(_detail!.definitionHtml),
                          style: {
                            'body': Style(
                              fontSize: FontSize(widget.fontSize - 2),
                              fontFamily: 'Gentium',
                              margin: Margins.zero,
                              padding: HtmlPaddings.zero,
                            ),
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Полная статья словаря (bottom sheet)
// ─────────────────────────────────────────────────────────────────────────────
class WordFullView extends StatelessWidget {
  final WordModel          word;
  final WordDetail         detail;
  final double             fontSize;
  final BibleLinkCallback? onBibleLink;

  const WordFullView({
    super.key,
    required this.word,
    required this.detail,
    required this.fontSize,
    this.onBibleLink,
  });

  void _handleLink(String? url, BuildContext context) {
    if (url == null) return;
    if (!url.startsWith('B:')) return;
    final ref = _parseBibleHref(url);
    if (ref == null || onBibleLink == null) return;
    onBibleLink!(ref.book, ref.chapter, ref.verse);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    // Заголовок: лемма крупно, форма в тексте — мелко под ней
    final headTitle  = detail.lexeme ?? word.word;
    final showInText = detail.lexeme != null && detail.lexeme != word.word;

    return DraggableScrollableSheet(
      initialChildSize: 0.92,
      minChildSize:     0.4,
      maxChildSize:     1.0,
      expand: false,
      builder: (ctx, controller) => Column(
        children: [
          // Handle bar
          Container(
            width: 40, height: 4,
            margin: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: Colors.grey[400],
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Title row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      headTitle,
                      style: TextStyle(
                        fontFamily: 'Gentium',
                        fontSize: fontSize + 2,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (showInText)
                      Text(
                        'в тексте: ${word.word}',
                        style: TextStyle(
                          fontFamily: 'Gentium',
                          fontSize: fontSize - 2,
                          fontStyle: FontStyle.italic,
                          color: Theme.of(ctx).colorScheme.secondary,
                        ),
                      ),
                  ],
                ),
              ),
              if (word.strongs != null)
                Chip(
                  label: Text('G${word.strongs}'),
                  visualDensity: VisualDensity.compact,
                ),
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.of(ctx).pop(),
              ),
            ]),
          ),

          if (detail.morphologyText.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  detail.morphologyText,
                  style: TextStyle(
                    fontStyle: FontStyle.italic,
                    fontSize: fontSize - 2,
                    color: Theme.of(ctx).colorScheme.secondary,
                  ),
                ),
              ),
            ),

          const Divider(),

          // Полный HTML со ссылками
          Expanded(
            child: SingleChildScrollView(
              controller: controller,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Html(
                data: detail.definitionHtml,
                onLinkTap: (url, attributes, element) =>
                    _handleLink(url, ctx),   // передаём ctx от builder-а
                style: {
                  'body': Style(
                    fontSize:   FontSize(fontSize),
                    fontFamily: 'Gentium',
                    margin:     Margins.zero,
                    padding:    HtmlPaddings.zero,
                  ),
                  'a': Style(
                    color: Colors.blue,
                    textDecoration: TextDecoration.underline,
                  ),
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
