// lib/search_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/app_state.dart';
import '../../../core/db/db_service.dart' show normalizeGreek;
import '../../../core/models/models.dart';

enum _SearchMode { word, strongs, morphology, multiWord }

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  _SearchMode _mode = _SearchMode.word;

  // Single search
  final _ctrl = TextEditingController();

  // Multi-word search
  final List<_TermInput> _terms = [_TermInput()];

  // Morphology
  String? _morphFirst;
  String? _morphSecond;

  List<_RichResult> _results  = [];
  bool _loading   = false;
  bool _searched  = false;

  @override
  void dispose() {
    _ctrl.dispose();
    for (final t in _terms) {
      t.ctrl.dispose();
    }
    super.dispose();
  }

  // ── Search dispatcher ──────────────────────────────────────────────────────
  Future<void> _search() async {
    final db = context.read<AppState>().db;
    setState(() { _loading = true; _results = []; });

    try {
      List<SearchResult> raw;

      switch (_mode) {
        case _SearchMode.word:
          final q = _ctrl.text.trim();
          if (q.isEmpty) { setState(() => _loading = false); return; }
          raw = await db.searchByWord(q);

        case _SearchMode.strongs:
          final q = _ctrl.text.trim();
          if (q.isEmpty) { setState(() => _loading = false); return; }
          raw = await db.searchByStrongs(q);

        case _SearchMode.morphology:
          final morph = [_morphFirst, _morphSecond]
              .where((s) => s != null && s.isNotEmpty).join('-');
          if (morph.isEmpty) { setState(() => _loading = false); return; }
          raw = await db.searchByMorphology(morph);

        case _SearchMode.multiWord:
          final terms = _terms
              .where((t) => t.ctrl.text.trim().isNotEmpty)
              .map((t) => SearchTerm(type: t.type, value: t.ctrl.text.trim()))
              .toList();
          if (terms.isEmpty) { setState(() => _loading = false); return; }
          raw = await db.searchMultiTerm(terms);
      }

      // Load full verses
      final rich = <_RichResult>[];
      for (final r in raw) {
        final vw = await db.getVerseWords(r.bookNumber, r.chapter, r.verse);
        rich.add(_RichResult(result: r, verseWords: vw));
      }
      setState(() { _results = rich; _searched = true; });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ошибка: $e')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ── Active query for highlight ─────────────────────────────────────────────
  List<String> get _matchNorms {
    if (_mode == _SearchMode.word) return [normalizeGreek(_ctrl.text.trim())];
    if (_mode == _SearchMode.multiWord) {
      return _terms
          .where((t) => t.type == SearchTermType.word && t.ctrl.text.isNotEmpty)
          .map((t) => normalizeGreek(t.ctrl.text.trim()))
          .toList();
    }
    return [];
  }

  List<String> get _matchStrongs {
    if (_mode == _SearchMode.strongs) {
      return [_ctrl.text.trim().replaceAll(RegExp(r'^[GgА-Яа-я]+'), '')];
    }
    if (_mode == _SearchMode.multiWord) {
      return _terms
          .where((t) => t.type == SearchTermType.strongs && t.ctrl.text.isNotEmpty)
          .map((t) => t.ctrl.text.trim().replaceAll(RegExp(r'^[GgА-Яа-я]+'), ''))
          .toList();
    }
    return [];
  }

  // ── Build ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('Поиск')),
      body: Column(children: [
        if (state.isIndexing)
          LinearProgressIndicator(value: state.indexProgress, minHeight: 2),

        // Mode chips
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: Row(children: [
            _chip('Слово',        _SearchMode.word),
            const SizedBox(width: 8),
            _chip('Стронг',       _SearchMode.strongs),
            const SizedBox(width: 8),
            _chip('Морфология',   _SearchMode.morphology),
            const SizedBox(width: 8),
            _chip('Несколько слов', _SearchMode.multiWord),
          ]),
        ),

        // Input area
        ..._buildInput(),

        const SizedBox(height: 4),

        // Results
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _results.isEmpty
                  ? Center(child: Text(
                      _searched ? 'Ничего не найдено' : 'Введите запрос',
                      style: const TextStyle(color: Colors.grey)))
                  : _ResultsList(
                      results:       _results,
                      matchNorms:    _matchNorms,
                      matchStrongs:  _matchStrongs,
                    ),
        ),
      ]),
    );
  }

  List<Widget> _buildInput() {
    switch (_mode) {
      case _SearchMode.morphology:
        return [
          _MorphPicker(onChanged: (f, s) =>
              setState(() { _morphFirst = f; _morphSecond = s; })),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            child: Align(alignment: Alignment.centerLeft,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.search),
                label: const Text('Найти'),
                onPressed: _search)),
          ),
        ];

      case _SearchMode.multiWord:
        return [
          ..._terms.asMap().entries.map((e) => _TermRow(
            input: e.value,
            index: e.key,
            onRemove: _terms.length > 1
                ? () => setState(() { _terms[e.key].ctrl.dispose(); _terms.removeAt(e.key); })
                : null,
          )),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            child: Row(children: [
              TextButton.icon(
                icon: const Icon(Icons.add),
                label: const Text('Ещё условие'),
                onPressed: () => setState(() => _terms.add(_TermInput()))),
              const Spacer(),
              ElevatedButton.icon(
                icon: const Icon(Icons.search),
                label: const Text('Найти (в одном стихе)'),
                onPressed: _search),
            ]),
          ),
        ];

      default:
        return [Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: TextField(
            controller: _ctrl,
            autofocus: true,
            textInputAction: TextInputAction.search,
            decoration: InputDecoration(
              hintText: _mode == _SearchMode.strongs
                  ? 'Номер Стронга (напр.: 1234 или G1234)'
                  : 'Слово или часть (с диакритикой или без)',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: _search),
            ),
            onSubmitted: (_) => _search(),
          ),
        )];
    }
  }

  Widget _chip(String label, _SearchMode m) => ChoiceChip(
    label: Text(label),
    selected: _mode == m,
    onSelected: (_) => setState(() {
      _mode = m; _results = []; _searched = false;
    }),
  );
}

// ── Multi-word term input ──────────────────────────────────────────────────
class _TermInput {
  SearchTermType type = SearchTermType.word;
  final TextEditingController ctrl = TextEditingController();
}

class _TermRow extends StatefulWidget {
  final _TermInput  input;
  final int         index;
  final VoidCallback? onRemove;
  const _TermRow({required this.input, required this.index, this.onRemove});
  @override
  State<_TermRow> createState() => _TermRowState();
}

class _TermRowState extends State<_TermRow> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 2, 12, 2),
      child: Row(children: [
        // Type toggle
        SegmentedButton<SearchTermType>(
          segments: const [
            ButtonSegment(value: SearchTermType.word,    label: Text('Слово')),
            ButtonSegment(value: SearchTermType.strongs, label: Text('G#')),
          ],
          selected: {widget.input.type},
          onSelectionChanged: (s) =>
              setState(() => widget.input.type = s.first),
          style: const ButtonStyle(
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: TextField(
            controller: widget.input.ctrl,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(
              hintText: widget.input.type == SearchTermType.strongs
                  ? 'Номер Стронга' : 'Греческое слово',
              border: const OutlineInputBorder(),
              isDense: true,
            ),
          ),
        ),
        if (widget.onRemove != null)
          IconButton(icon: const Icon(Icons.remove_circle_outline),
              onPressed: widget.onRemove),
      ]),
    );
  }
}

// ── Rich result ────────────────────────────────────────────────────────────
class _RichResult {
  final SearchResult    result;
  final List<WordModel> verseWords;
  const _RichResult({required this.result, required this.verseWords});
}

// ── Results list ─────────────────────────────────────────────────────────────
class _ResultsList extends StatelessWidget {
  final List<_RichResult> results;
  final List<String>      matchNorms;
  final List<String>      matchStrongs;

  const _ResultsList({
    required this.results,
    required this.matchNorms,
    required this.matchStrongs,
  });

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text('Найдено: ${results.length}${results.length >= 300 ? '+' : ''}',
            style: const TextStyle(fontSize: 12, color: Colors.grey)))),
      Expanded(
        child: ListView.separated(
          itemCount: results.length,
          separatorBuilder: (_, __) => const Divider(height: 1, indent: 12),
          itemBuilder: (_, i) => _ResultTile(
            rich:        results[i],
            matchNorms:  matchNorms,
            matchStrongs: matchStrongs,
          ),
        ),
      ),
    ]);
  }
}

class _ResultTile extends StatelessWidget {
  final _RichResult    rich;
  final List<String>   matchNorms;
  final List<String>   matchStrongs;

  const _ResultTile({required this.rich, required this.matchNorms, required this.matchStrongs});

  bool _isMatch(WordModel w) {
    final normWord = normalizeGreek(w.word);
    for (final q in matchNorms) {
      if (q.isNotEmpty && normWord.contains(q)) return true;
    }
    for (final s in matchStrongs) {
      if (s.isNotEmpty && (w.strongs ?? '').contains(s)) return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final r   = rich.result;
    final s   = context.read<AppState>();
    final fs  = s.fontSize;

    final spans = <InlineSpan>[];
    for (final w in rich.verseWords) {
      final matched = _isMatch(w);
      spans.add(TextSpan(
        text: '${w.word} ',
        style: TextStyle(
          fontFamily: 'Gentium',
          fontSize:   matched ? fs + 1 : fs - 2,
          fontWeight: matched ? FontWeight.bold : FontWeight.normal,
          color:      matched
              ? Theme.of(context).colorScheme.primary
              : Theme.of(context).colorScheme.onSurface,
        ),
      ));
    }

    return InkWell(
      onTap: () {
        Navigator.of(context).pop();
        s.navigateToVerse(r.bookNumber, r.chapter, r.verse,
            highlightStrongs: r.strongs);
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 60, child: Column(children: [
            Text(r.bookShortName,
              style: TextStyle(fontFamily: 'Gentium', fontSize: 11,
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.bold),
              textAlign: TextAlign.center),
            Text('${r.chapter}:${r.verse}',
              style: const TextStyle(fontSize: 11, color: Colors.grey),
              textAlign: TextAlign.center),
          ])),
          const SizedBox(width: 8),
          Expanded(child: RichText(text: TextSpan(children: spans))),
        ]),
      ),
    );
  }
}

// ── Morphology picker ──────────────────────────────────────────────────────
class _MorphPicker extends StatefulWidget {
  final void Function(String?, String?) onChanged;
  const _MorphPicker({required this.onChanged});
  @override
  State<_MorphPicker> createState() => _MorphPickerState();
}

class _MorphPickerState extends State<_MorphPicker> {
  List<MorphEntry> _first = [], _second = [];
  String? _selF, _selS;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final db = context.read<AppState>().db;
    final f  = await db.getFirstLevelMorphCodes();
    final s  = await db.getSecondLevelMorphCodes();
    if (mounted) setState(() { _first = f; _second = s; });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Row(children: [
        Expanded(child: DropdownButtonFormField<String>(
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Тип слова',
              border: OutlineInputBorder(), isDense: true),
          initialValue: _selF,
          items: [
            const DropdownMenuItem(value: null, child: Text('—')),
            ..._first.map((e) => DropdownMenuItem(value: e.indication,
                child: Text('${e.indication} — ${e.meaning}',
                    overflow: TextOverflow.ellipsis))),
          ],
          onChanged: (v) { setState(() => _selF = v); widget.onChanged(_selF, _selS); },
        )),
        const SizedBox(width: 8),
        Expanded(child: DropdownButtonFormField<String>(
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Падеж / время',
              border: OutlineInputBorder(), isDense: true),
          initialValue: _selS,
          items: [
            const DropdownMenuItem(value: null, child: Text('—')),
            ..._second.map((e) => DropdownMenuItem(value: e.indication,
                child: Text('${e.indication} — ${e.meaning}',
                    overflow: TextOverflow.ellipsis))),
          ],
          onChanged: (v) { setState(() => _selS = v); widget.onChanged(_selF, _selS); },
        )),
      ]),
    );
  }
}
