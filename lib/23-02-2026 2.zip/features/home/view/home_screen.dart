// lib/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../../core/app_state.dart';
import '../../../core/models/models.dart';
import '../../../word_popup.dart';
import '../../search/view/search_screen.dart';
import '../../hotkey_settings/view/hotkey_settings_screen.dart';

const double kBookGridFontSize = 20.0;

bool _isPunct(String w) =>
    RegExp(r'^[.,;·!?:»«—–\-\u037E\u0387\u00B7]+$').hasMatch(w.trim());

// ─────────────────────────────────────────────────────────────────────────────
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController _scroll = ScrollController();

  // "chapter:verse" → GlobalKey на виджет стиха
  final Map<String, GlobalKey> _keys = {};

  // Последний navVersion, по которому уже сделан скролл
  int _lastNavVersion = -1;

  // Следим за сменой книги, чтобы сбросить кэш ключей
  int _lastBook = -1;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
  }

  // ── Скролл к нужному стиху ────────────────────────────────────────────────
  // Двухшаговый алгоритм:
  //   1. Прыгаем к приближённой позиции по индексу — чтобы ListView.builder
  //      построил виджеты рядом с целью.
  //   2. В следующем кадре вызываем Scrollable.ensureVisible на точный ключ.
  // Если ключ всё ещё null — повторяем (до 4 попыток).
  void _scrollToVerse(int chapter, int verse, {int attempt = 0}) {
    if (!mounted || !_scroll.hasClients || attempt > 4) return;

    // Шаг 2: точный скролл, если виджет уже в дереве
    final key = _keys['$chapter:$verse'];
    if (key?.currentContext != null) {
      Scrollable.ensureVisible(
        key!.currentContext!,
        alignment: 0.0,       // верхний край экрана
        duration: Duration.zero,
      );
      return;
    }

    // Шаг 1: приближённый прыжок
    final verses = context.read<AppState>().verses;
    final idx = verses.indexWhere(
        (v) => v.chapter == chapter && v.verse == verse);

    if (idx >= 0) {
      final maxExt = _scroll.position.maxScrollExtent;
      if (maxExt > 0) {
        final approx = (idx / verses.length * maxExt).clamp(0.0, maxExt);
        _scroll.jumpTo(approx);
      }
    }

    // После прыжка ListView построит нужные элементы — пробуем снова
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToVerse(chapter, verse, attempt: attempt + 1);
    });
  }

  // ── Scroll listener: трекинг текущего стиха ───────────────────────────────
  void _onScroll() {
    if (!mounted) return;
    final state = context.read<AppState>();
    if (state.isLoadingText) return;

    for (final entry in _keys.entries) {
      final ctx = entry.value.currentContext;
      if (ctx == null) continue;
      final box = ctx.findRenderObject() as RenderBox?;
      if (box == null) continue;
      final dy = box.localToGlobal(Offset.zero).dy;
      if (dy >= -40 && dy < 200) {
        final parts = entry.key.split(':');
        if (parts.length == 2) {
          final ch = int.tryParse(parts[0]);
          final v  = int.tryParse(parts[1]);
          if (ch != null && v != null) state.updateVisibleVerse(ch, v);
        }
        break;
      }
    }
  }

  // ── Page scroll ───────────────────────────────────────────────────────────
  void _pageDown() {
    if (!_scroll.hasClients) return;
    final anim   = context.read<AppState>().animationsEnabled;
    final target = (_scroll.offset + _scroll.position.viewportDimension * 0.92)
        .clamp(0.0, _scroll.position.maxScrollExtent);
    anim
        ? _scroll.animateTo(target,
            duration: const Duration(milliseconds: 220), curve: Curves.easeOut)
        : _scroll.jumpTo(target);
  }

  void _pageUp() {
    if (!_scroll.hasClients) return;
    final anim   = context.read<AppState>().animationsEnabled;
    final target = (_scroll.offset - _scroll.position.viewportDimension * 0.92)
        .clamp(0.0, _scroll.position.maxScrollExtent);
    anim
        ? _scroll.animateTo(target,
            duration: const Duration(milliseconds: 220), curve: Curves.easeOut)
        : _scroll.jumpTo(target);
  }

  // ── AppBar actions ─────────────────────────────────────────────────────────
  void _showBookPicker() =>
      showDialog(context: context, builder: (_) => const _BookChapterDialog());

  void _showSettings() => showModalBottomSheet(
      context: context,
      builder: (_) =>
          _SettingsSheet(onPageDown: _pageDown, onPageUp: _pageUp));

  void _openSearch() => Navigator.of(context)
      .push(MaterialPageRoute(builder: (_) => const SearchScreen()));

  // ── Keyboard ──────────────────────────────────────────────────────────────
  KeyEventResult _handleKey(FocusNode _, KeyEvent e) {
    if (e is! KeyDownEvent) return KeyEventResult.ignored;
    final s = context.read<AppState>();
    if (s.isScrollDownKey(e.logicalKey)) {
      _pageDown();
      return KeyEventResult.handled;
    }
    if (s.isScrollUpKey(e.logicalKey)) {
      _pageUp();
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  // ── Переход по ссылке из словаря ──────────────────────────────────────────
  Future<void> _onBibleLink(int book, int ch, int v, {String? strongs}) async {
    await context
        .read<AppState>()
        .navigateToVerse(book, ch, v, highlightStrongs: strongs);
  }

  // ── Build ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    // Новый navVersion → скролл после рендера
    if (state.navVersion != _lastNavVersion && !state.isLoadingText) {
      _lastNavVersion = state.navVersion;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToVerse(state.currentChapter, state.currentVerse);
      });
    }

    final bookName = state.isLoadingBooks
        ? '…'
        : (state.books
                .where((b) => b.bookNumber == state.currentBook)
                .firstOrNull
                ?.shortName ??
            '?');

    return Focus(
      autofocus: true,
      onKeyEvent: _handleKey,
      child: Scaffold(
        appBar: AppBar(
          leading: TextButton(
            onPressed: _showBookPicker,
            child: Text(
              '$bookName ${state.currentChapter}:${state.currentVerse}',
              style: const TextStyle(
                  fontFamily: 'Gentium', fontSize: 20, color: Colors.white),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
          leadingWidth: 170,
          title: const SizedBox.shrink(),
          actions: [
            IconButton(icon: const Icon(Icons.search), onPressed: _openSearch),
            IconButton(
              icon: const Icon(Icons.menu_book_rounded),
              tooltip: 'Словари',
              onPressed: () => Navigator.pushNamed(context, '/dictionaries'),
            ),
            IconButton(
                icon: const Icon(Icons.settings), onPressed: _showSettings),
          ],
        ),
        body: Column(
          children: [
            if (state.isIndexing)
              LinearProgressIndicator(
                value: state.indexProgress == 0 ? null : state.indexProgress,
                minHeight: 2,
              ),
            Expanded(
              child: state.isLoadingText
                  ? const Center(child: CircularProgressIndicator())
                  : state.error != null
                      ? Center(child: Text('Ошибка: ${state.error}'))
                      : _buildText(state),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildText(AppState state) {
    // При смене книги старые ключи указывают на мёртвые виджеты —
    // обязательно очищаем, иначе putIfAbsent вернёт старый ключ
    if (state.currentBook != _lastBook) {
      _keys.clear();
      _lastBook = state.currentBook;
    }

    final verses = state.verses;
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 60),
      itemCount: verses.length,
      itemBuilder: (ctx, idx) {
        final verse = verses[idx];
        final keyId = '${verse.chapter}:${verse.verse}';
        _keys.putIfAbsent(keyId, () => GlobalKey());
        final key = _keys[keyId]!;

        final showHeader =
            idx == 0 || verses[idx - 1].chapter != verse.chapter;

        return Column(
          key: key,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (showHeader)
              Padding(
                padding: const EdgeInsets.only(top: 20, bottom: 4),
                child: Text(
                  'Глава ${verse.chapter}',
                  style: TextStyle(
                    fontFamily: 'Gentium',
                    fontSize: state.fontSize + 2,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ),
            _VerseBlock(
              verse:            verse,
              fontSize:         state.fontSize,
              db:               state.db,
              highlight:        state.highlightTarget,
              animated:         state.animationsEnabled,
              onBibleLink:      _onBibleLink,
              onClearHighlight: state.clearHighlight,
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _scroll.removeListener(_onScroll);
    _scroll.dispose();
    super.dispose();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Book + Chapter + Verse picker  (3 шага)
// ─────────────────────────────────────────────────────────────────────────────
class _BookChapterDialog extends StatefulWidget {
  const _BookChapterDialog();
  @override
  State<_BookChapterDialog> createState() => _BookChapterDialogState();
}

enum _Step { book, chapter, verse }

class _BookChapterDialogState extends State<_BookChapterDialog> {
  _Step _step            = _Step.book;
  int   _pickedChapter   = 1;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    const titles = {
      _Step.book:    'Выберите книгу',
      _Step.chapter: 'Выберите главу',
      _Step.verse:   'Выберите стих',
    };

    return Dialog(
      insetPadding: const EdgeInsets.all(12),
      child: ConstrainedBox(
        constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.82),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 8, 8),
              child: Row(children: [
                if (_step != _Step.book)
                  IconButton(
                    icon: const Icon(Icons.arrow_back),
                    onPressed: () => setState(() {
                      _step = _step == _Step.verse ? _Step.chapter : _Step.book;
                    }),
                  ),
                Expanded(
                    child: Text(titles[_step]!,
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.bold))),
                IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context)),
              ]),
            ),
            const Divider(height: 1),

            Flexible(
              child: switch (_step) {
                // ── Шаг 1: выбор книги ───────────────────────────────────
                _Step.book => _Grid(
                    items: state.books
                        .map((b) => _GridItem(
                              label:    b.shortName,
                              selected: b.bookNumber == state.currentBook,
                            ))
                        .toList(),
                    onTap: (idx) async {
                      final book = state.books[idx];
                      // silent: true — загружаем данные для пикера,
                      // но НЕ прокручиваем HomeScreen до выбора стиха.
                      await context.read<AppState>().loadBook(
                            book.bookNumber,
                            silent: true,
                          );
                      if (mounted) setState(() => _step = _Step.chapter);
                    },
                  ),

                // ── Шаг 2: выбор главы ───────────────────────────────────
                _Step.chapter => _Grid(
                    items: state.allChapters
                        .map((ch) => _GridItem(
                              label:    '$ch',
                              selected: ch == state.currentChapter,
                            ))
                        .toList(),
                    onTap: (idx) {
                      _pickedChapter = state.allChapters[idx];
                      setState(() => _step = _Step.verse);
                    },
                  ),

                // ── Шаг 3: выбор стиха ───────────────────────────────────
                _Step.verse => _Grid(
                    items: state.verses
                        .where((v) => v.chapter == _pickedChapter)
                        .map((v) => _GridItem(
                              label: '${v.verse}',
                              selected: v.verse == state.currentVerse &&
                                  _pickedChapter == state.currentChapter,
                            ))
                        .toList(),
                    onTap: (idx) {
                      final verseNum = state.verses
                          .where((v) => v.chapter == _pickedChapter)
                          .elementAt(idx)
                          .verse;
                      Navigator.pop(context);
                      context
                          .read<AppState>()
                          .selectChapterAndVerse(_pickedChapter, verseNum);
                    },
                  ),
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ── Универсальная сетка ───────────────────────────────────────────────────────
class _GridItem {
  final String label;
  final bool   selected;
  const _GridItem({required this.label, required this.selected});
}

class _Grid extends StatelessWidget {
  final List<_GridItem>    items;
  final void Function(int) onTap;
  const _Grid({required this.items, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(6),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 6,
        childAspectRatio: 2.6,
        mainAxisSpacing: 4,
        crossAxisSpacing: 4,
      ),
      itemCount: items.length,
      itemBuilder: (_, idx) {
        final item = items[idx];
        return InkWell(
          onTap: () => onTap(idx),
          borderRadius: BorderRadius.circular(4),
          child: Container(
            decoration: BoxDecoration(
              color: item.selected
                  ? Theme.of(context).colorScheme.primary
                  : Theme.of(context).colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(4),
            ),
            alignment: Alignment.center,
            child: Text(
              item.label,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize:   kBookGridFontSize,
                fontFamily: 'Gentium',
                color: item.selected
                    ? Theme.of(context).colorScheme.onPrimary
                    : Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ),
        );
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Settings bottom sheet
// ─────────────────────────────────────────────────────────────────────────────
class _SettingsSheet extends StatelessWidget {
  final VoidCallback onPageDown;
  final VoidCallback onPageUp;
  const _SettingsSheet({required this.onPageDown, required this.onPageUp});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (_, state, __) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                    color: Colors.grey[400],
                    borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Row(children: [
                const Text('Размер шрифта', style: TextStyle(fontSize: 16)),
                const Spacer(),
                IconButton(
                    icon: const Icon(Icons.remove),
                    onPressed: () => state.setFontSize(state.fontSize - 1)),
                SizedBox(
                    width: 48,
                    child: Text('${state.fontSize.toInt()}pt',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold))),
                IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: () => state.setFontSize(state.fontSize + 1)),
              ]),
            ),
            SwitchListTile(
              title: const Text('Анимации'),
              subtitle: const Text('Выключить для экрана E-Ink'),
              value: state.animationsEnabled,
              onChanged: state.setAnimations,
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.keyboard),
              title: const Text('Горячие клавиши'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const HotkeySettingsScreen()));
              },
            ),
            ListTile(
              leading: const Icon(Icons.refresh),
              title: const Text('Перестроить поисковый индекс'),
              onTap: () {
                Navigator.pop(context);
                state.rebuildIndex();
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Verse block
// ─────────────────────────────────────────────────────────────────────────────
class _VerseBlock extends StatelessWidget {
  final VerseModel   verse;
  final double       fontSize;
  final dynamic      db;
  final HighlightTarget? highlight;
  final bool         animated;
  final Future<void> Function(int, int, int, {String? strongs}) onBibleLink;
  final VoidCallback onClearHighlight;

  const _VerseBlock({
    required this.verse,
    required this.fontSize,
    required this.db,
    required this.highlight,
    required this.animated,
    required this.onBibleLink,
    required this.onClearHighlight,
  });

  @override
  Widget build(BuildContext context) {
    final widgets = <Widget>[];

    // Номер стиха
    widgets.add(Padding(
      padding: const EdgeInsets.only(right: 3),
      child: Text('${verse.verse}',
          style: TextStyle(
              fontSize: fontSize - 5,
              color: Colors.blueGrey,
              fontWeight: FontWeight.bold)),
    ));

    for (int i = 0; i < verse.words.length; i++) {
      final w           = verse.words[i];
      final isPunct     = _isPunct(w.word);
      final nextIsPunct =
          (i + 1 < verse.words.length) && _isPunct(verse.words[i + 1].word);

      final shouldBlink = highlight != null &&
          highlight!.chapter == verse.chapter &&
          highlight!.verse   == verse.verse &&
          (highlight!.strongs == null || highlight!.strongs == w.strongs);

      widgets.add(_WordTile(
        word:            w,
        fontSize:        fontSize,
        db:              db,
        isPunct:         isPunct,
        noTrailingSpace: nextIsPunct,
        shouldBlink:     shouldBlink,
        animated:        animated,
        onBibleLink:     onBibleLink,
        onBlinkDone:     onClearHighlight,
      ));
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Wrap(crossAxisAlignment: WrapCrossAlignment.end, children: widgets),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Word tile
// ─────────────────────────────────────────────────────────────────────────────
class _WordTile extends StatefulWidget {
  final WordModel  word;
  final double     fontSize;
  final dynamic    db;
  final bool       isPunct;
  final bool       noTrailingSpace;
  final bool       shouldBlink;
  final bool       animated;
  final Future<void> Function(int, int, int, {String? strongs}) onBibleLink;
  final VoidCallback onBlinkDone;

  const _WordTile({
    required this.word,
    required this.fontSize,
    required this.db,
    required this.isPunct,
    required this.noTrailingSpace,
    required this.shouldBlink,
    required this.animated,
    required this.onBibleLink,
    required this.onBlinkDone,
  });

  @override
  State<_WordTile> createState() => _WordTileState();
}

class _WordTileState extends State<_WordTile>
    with SingleTickerProviderStateMixin {
  bool _tapped = false;
  OverlayEntry? _overlay;
  AnimationController? _blinkCtrl;
  bool _blinkStarted = false;

  @override
  void initState() {
    super.initState();
    if (widget.animated) {
      _blinkCtrl = AnimationController(
          vsync: this, duration: const Duration(milliseconds: 280));
    }
    if (widget.shouldBlink) _startBlink();
  }

  @override
  void didUpdateWidget(_WordTile old) {
    super.didUpdateWidget(old);
    if (widget.shouldBlink && !_blinkStarted) _startBlink();
  }

  void _startBlink() {
    if (_blinkStarted) return;
    _blinkStarted = true;
    if (!widget.animated || _blinkCtrl == null) {
      Future.delayed(const Duration(milliseconds: 80), () {
        if (mounted) setState(() => _tapped = true);
        Future.delayed(const Duration(milliseconds: 300), () {
          if (mounted) {
            setState(() => _tapped = false);
            widget.onBlinkDone();
          }
        });
      });
      return;
    }
    Future.delayed(const Duration(milliseconds: 50), () async {
      if (!mounted) return;
      for (int i = 0; i < 2; i++) {
        await _blinkCtrl!.forward();
        await _blinkCtrl!.reverse();
      }
      if (mounted) widget.onBlinkDone();
    });
  }

  @override
  void dispose() {
    _overlay?.remove();
    _blinkCtrl?.dispose();
    super.dispose();
  }

  void _showPopup(BuildContext ctx) {
    final box    = ctx.findRenderObject() as RenderBox;
    final offset = box.localToGlobal(Offset.zero);
    final sz     = box.size;
    final sw     = MediaQuery.of(ctx).size.width;
    final sh     = MediaQuery.of(ctx).size.height;
    setState(() => _tapped = true);

    _overlay = OverlayEntry(builder: (_) => Stack(children: [
      Positioned.fill(child: GestureDetector(
          onTap: _dismiss,
          behavior: HitTestBehavior.translucent,
          child: const SizedBox.expand())),
      Positioned(
        left: offset.dx.clamp(8.0, sw - 350.0),
        top:  (offset.dy + sz.height + 6).clamp(8.0, sh - 280.0),
        child: WordQuickView(
          word:     widget.word,
          db:       widget.db,
          fontSize: widget.fontSize,
          onClose:  _dismiss,
          onBibleLink: (b, ch, v) {
            _dismiss();
            widget.onBibleLink(b, ch, v);
          },
        ),
      ),
    ]));
    Overlay.of(ctx).insert(_overlay!);
  }

  void _dismiss() {
    _overlay?.remove();
    _overlay = null;
    if (mounted) setState(() => _tapped = false);
  }

  @override
  Widget build(BuildContext context) {
    final displayText = widget.isPunct
        ? widget.word.word
        : (widget.noTrailingSpace ? widget.word.word : '${widget.word.word} ');

    final textWidget = Text(displayText,
        style: TextStyle(
            fontFamily: 'Gentium', fontSize: widget.fontSize, height: 1.65));

    Color bg = Colors.transparent;
    if (_tapped) bg = Theme.of(context).colorScheme.primary.withOpacity(0.18);

    if (widget.animated && _blinkCtrl != null && !_tapped) {
      return GestureDetector(
        onTap: () => _overlay != null ? _dismiss() : _showPopup(context),
        child: AnimatedBuilder(
          animation: _blinkCtrl!,
          builder: (_, __) => Container(
            color: ColorTween(
                    begin: Colors.transparent,
                    end: Colors.blue.withOpacity(0.35))
                .lerp(_blinkCtrl!.value),
            child: widget.isPunct
                ? Transform.translate(
                    offset: Offset((widget.fontSize * 0.0), 1),
                    child: textWidget)
                : textWidget,
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: () => _overlay != null ? _dismiss() : _showPopup(context),
      child: Container(
        color: bg,
        child: widget.isPunct
            ? Transform.translate(
                offset: Offset((widget.fontSize * 0.0), 1),
                child: textWidget)
            : textWidget,
      ),
    );
  }
}
