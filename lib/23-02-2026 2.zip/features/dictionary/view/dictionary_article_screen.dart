// lib/features/dictionary/view/dictionary_article_screen.dart
//
// Полная статья словаря. Открывается как отдельный экран (не bottom sheet),
// чтобы работали горячие клавиши прокрутки из AppState (E-Ink / внешняя клавиатура).

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:provider/provider.dart';
import '../../../core/app_state.dart';
import '../../../core/models/models.dart';

class DictionaryArticleScreen extends StatefulWidget {
  const DictionaryArticleScreen({super.key, required this.entry});

  final DictionaryEntry entry;

  @override
  State<DictionaryArticleScreen> createState() =>
      _DictionaryArticleScreenState();
}

class _DictionaryArticleScreenState extends State<DictionaryArticleScreen> {
  final _scroll = ScrollController();

  // ── Прокрутка ─────────────────────────────────────────────────────────────
  void _pageDown() {
    if (!_scroll.hasClients) return;
    final s      = context.read<AppState>();
    final target = (_scroll.offset + _scroll.position.viewportDimension * 0.92)
        .clamp(0.0, _scroll.position.maxScrollExtent);
    s.animationsEnabled
        ? _scroll.animateTo(target,
            duration: const Duration(milliseconds: 220), curve: Curves.easeOut)
        : _scroll.jumpTo(target);
  }

  void _pageUp() {
    if (!_scroll.hasClients) return;
    final s      = context.read<AppState>();
    final target = (_scroll.offset - _scroll.position.viewportDimension * 0.92)
        .clamp(0.0, _scroll.position.maxScrollExtent);
    s.animationsEnabled
        ? _scroll.animateTo(target,
            duration: const Duration(milliseconds: 220), curve: Curves.easeOut)
        : _scroll.jumpTo(target);
  }

  // ── Клавиатура ────────────────────────────────────────────────────────────
  KeyEventResult _handleKey(FocusNode _, KeyEvent e) {
    if (e is! KeyDownEvent) return KeyEventResult.ignored;
    final s = context.read<AppState>();
    if (s.isScrollDownKey(e.logicalKey)) { _pageDown(); return KeyEventResult.handled; }
    if (s.isScrollUpKey(e.logicalKey))   { _pageUp();   return KeyEventResult.handled; }
    return KeyEventResult.ignored;
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final fontSize = appState.fontSize;
    final entry    = widget.entry;

    return Focus(
      autofocus: true,
      onKeyEvent: _handleKey,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            entry.term,
            style: const TextStyle(fontFamily: 'Gentium'),
          ),
        ),
        body: SingleChildScrollView(
          controller: _scroll,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
          child: Html(
            data: entry.definitionHtml,
            style: {
              'body': Style(
                fontSize:   FontSize(fontSize),
                fontFamily: 'Gentium',
                lineHeight: LineHeight(1.7),
                margin:     Margins.zero,
                padding:    HtmlPaddings.zero,
              ),
              'a': Style(
                color:          Colors.blue,
                textDecoration: TextDecoration.underline,
              ),
            },
          ),
        ),

        // Кнопки страниц — дублируют горячие клавиши для тачскрина
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton.outlined(
                  icon: const Icon(Icons.keyboard_arrow_up),
                  tooltip: 'Страница вверх',
                  onPressed: _pageUp,
                ),
                IconButton.outlined(
                  icon: const Icon(Icons.keyboard_arrow_down),
                  tooltip: 'Страница вниз',
                  onPressed: _pageDown,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
