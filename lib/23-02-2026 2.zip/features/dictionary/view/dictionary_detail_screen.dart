// lib/features/dictionary/view/dictionary_detail_screen.dart
//
// Список записей одного словаря с поиском и пагинацией.
// Клик на запись → DictionaryArticleScreen (полный текст + горячие клавиши).

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../provider/dictionary_provider.dart';
import '../widgets/dictionary_entry_tile.dart';
import 'dictionary_article_screen.dart';

class DictionaryDetailScreen extends StatefulWidget {
  const DictionaryDetailScreen({
    super.key,
    required this.dictionaryId,
    required this.dictionaryTitle,
  });

  final String dictionaryId;
  final String dictionaryTitle;

  @override
  State<DictionaryDetailScreen> createState() => _DictionaryDetailScreenState();
}

class _DictionaryDetailScreenState extends State<DictionaryDetailScreen> {
  final _searchCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  bool  _searchActive = false;

  @override
  void initState() {
    super.initState();
    _scrollCtrl.addListener(_onScroll);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DictionaryProvider>().loadEntries(
            dictionaryId: widget.dictionaryId,
          );
    });
  }

  void _onScroll() {
    if (_scrollCtrl.position.extentAfter < 200) {
      context.read<DictionaryProvider>().loadMore();
    }
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _runSearch(String q) => context.read<DictionaryProvider>().loadEntries(
        dictionaryId: widget.dictionaryId,
        query: q,
      );

  void _clearSearch() {
    _searchCtrl.clear();
    _runSearch('');
    setState(() => _searchActive = false);
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<DictionaryProvider>();

    return Scaffold(
      appBar: AppBar(
        title: _searchActive
            ? TextField(
                controller: _searchCtrl,
                autofocus: true,
                style: const TextStyle(color: Colors.white),
                cursorColor: Colors.white,
                decoration: const InputDecoration(
                  hintText: 'Поиск…',
                  hintStyle: TextStyle(color: Colors.white54),
                  border: InputBorder.none,
                ),
                onChanged: _runSearch,
              )
            : Text(widget.dictionaryTitle),
        actions: [
          if (_searchActive)
            IconButton(
              icon: const Icon(Icons.close),
              tooltip: 'Сбросить',
              onPressed: _clearSearch,
            )
          else
            IconButton(
              icon: const Icon(Icons.search),
              tooltip: 'Поиск',
              onPressed: () => setState(() => _searchActive = true),
            ),
        ],
      ),
      body: _buildBody(provider),
    );
  }

  Widget _buildBody(DictionaryProvider provider) {
    if (provider.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (provider.error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48, color: Colors.red),
            const SizedBox(height: 12),
            Text(provider.error!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => _runSearch(provider.currentQuery),
              child: const Text('Повторить'),
            ),
          ],
        ),
      );
    }
    if (provider.entries.isEmpty) {
      return Center(
        child: Text('Ничего не найдено',
            style: Theme.of(context).textTheme.bodyLarge),
      );
    }

    return ListView.separated(
      controller: _scrollCtrl,
      itemCount: provider.entries.length + (provider.isLoadingMore ? 1 : 0),
      separatorBuilder: (_, __) => const Divider(height: 1, indent: 16),
      itemBuilder: (context, i) {
        if (i >= provider.entries.length) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final entry = provider.entries[i];
        return DictionaryEntryTile(
          entry: entry,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => DictionaryArticleScreen(entry: entry),
            ),
          ),
        );
      },
    );
  }
}
