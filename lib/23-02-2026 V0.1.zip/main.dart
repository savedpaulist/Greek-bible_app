// lib/main.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app_state.dart';
import 'db_service.dart';
import 'prefs_service.dart';
import 'home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final db    = DBService();
  final prefs = PrefsService();

  await prefs.init();
  await db.init();

  runApp(
    ChangeNotifierProvider(
      create: (_) => AppState(db: db, prefs: prefs)..initialize(),
      child: const BibleApp(),
    ),
  );
}

class BibleApp extends StatelessWidget {
  const BibleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Греческая Библия',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF1B4B8A),
        fontFamily: 'Gentium',
        textTheme: const TextTheme(
          bodyMedium:  TextStyle(fontFamily: 'Gentium'),
          bodyLarge:   TextStyle(fontFamily: 'Gentium'),
          titleMedium: TextStyle(fontFamily: 'Gentium'),
          titleLarge:  TextStyle(fontFamily: 'Gentium'),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1B4B8A),
          foregroundColor: Colors.white,
          titleTextStyle: TextStyle(
            fontFamily: 'Gentium',
            fontSize: 18,
            color: Colors.white,
          ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
